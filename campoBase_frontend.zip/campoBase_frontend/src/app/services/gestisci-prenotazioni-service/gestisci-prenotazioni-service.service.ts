import { Injectable } from '@angular/core';
import { Prenotazione } from '../../model/model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GestisciPrenotazioniServiceService {

  

  private url = "http://localhost:8080";


  constructor(private http: HttpClient) { }


  getPrenotazioni() : Observable <Prenotazione[]>{

    return this.http.get<Prenotazione []>(`${this.url}/getAllPrenotazioni`, {withCredentials: true});
  }
  
  deletePrenotazione(id: number): Observable<String>{
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
  return this.http.post<string>(`${this.url}/deletePrenotazione?id=${id}`, null, { headers, responseType: 'text' as 'json' });
  }
  
}
