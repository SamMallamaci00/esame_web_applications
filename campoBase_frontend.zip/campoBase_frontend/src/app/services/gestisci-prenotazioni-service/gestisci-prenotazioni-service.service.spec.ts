import { TestBed } from '@angular/core/testing';

import { GestisciPrenotazioniServiceService } from './gestisci-prenotazioni-service.service';

describe('GestisciPrenotazioniServiceService', () => {
  let service: GestisciPrenotazioniServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GestisciPrenotazioniServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
