import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Pacchetto } from '../../model/model';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PacchettiService {

  private url = "http://localhost:8080";


  constructor(private http: HttpClient) { }


  getPacchettiAgenzia(agenzia : string) : Observable <Pacchetto[]>{
    return this.http.get<Pacchetto[]>(`${this.url}/getPacchettiAgenzia?agenzia=${agenzia}`, {withCredentials: true});
  }

  getPacchettiId(id: number): Observable <Pacchetto[]>{
    return this.http.get<Pacchetto[]>(`${this.url}/getPacchettiId?id=${id}`, {withCredentials: true});
  }

  getPacchetto(id: number) : Observable <Pacchetto>{
    return this.http.get<Pacchetto>(`${this.url}/getPacchetto?id=${id}`, {withCredentials: true});
  }

  savePacchetto(id: number, agenzia: string, prezzo: number, descrizione: string, immagine: string, titolo: string): Observable<String> {


    const formData = new FormData();

    // Aggiungi i campi di testo
    formData.append('id', id.toString());
    formData.append('agenzia', agenzia);
    formData.append('prezzo', prezzo.toString());
    formData.append('descrizione', descrizione);
    formData.append('immagine', immagine);
    formData.append('titolo', titolo);



    // Invia la richiesta POST con FormData
    return this.http.post<String>(`${this.url}/addPacchetto`, formData, {responseType: 'text' as 'json' });
}


deletePacchetto(id: number){
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
  return this.http.post<string>(`${this.url}/deletePacchetto?id=${id}`, null, { headers, responseType: 'text' as 'json' });
}

getPacchettiProxy(id : number){
  return this.http.get<Pacchetto[]>(`${this.url}/getPacchettiProxy?id=${id}`, {withCredentials: true});

}
}
