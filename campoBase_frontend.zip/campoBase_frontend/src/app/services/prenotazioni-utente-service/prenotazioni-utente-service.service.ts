import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Prenotazione } from '../../model/model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PrenotazioniUtenteServiceService {

  private url = "http://localhost:8080";


  constructor(private http: HttpClient) { }


  getPrenotazioniUtente(email:string) : Observable <Prenotazione[]>{

    return this.http.get<Prenotazione []>(`${this.url}/getPrenotazioniUtente?utente=${email}`, {withCredentials: true});
  }
  
    getRuolo(email : string): Observable <string>{
      return this.http.get(`${this.url}/getRuolo?email=${email}`, { responseType: 'text', withCredentials: true });
    }
  
}
