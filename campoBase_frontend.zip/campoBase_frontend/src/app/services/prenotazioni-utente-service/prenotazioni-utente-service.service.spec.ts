import { TestBed } from '@angular/core/testing';

import { PrenotazioniUtenteServiceService } from './prenotazioni-utente-service.service';

describe('PrenotazioniUtenteServiceService', () => {
  let service: PrenotazioniUtenteServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PrenotazioniUtenteServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
