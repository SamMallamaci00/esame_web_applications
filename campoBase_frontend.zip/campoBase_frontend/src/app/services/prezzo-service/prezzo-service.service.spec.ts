import { TestBed } from '@angular/core/testing';

import { PrezzoServiceService } from './prezzo-service.service';

describe('PrezzoServiceService', () => {
  let service: PrezzoServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PrezzoServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
