import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Prezzo } from '../../model/model';

@Injectable({
  providedIn: 'root'
})
export class PrezzoServiceService {
  private url : string = "http://localhost:8080";


  prezzoPacch = 0

  constructor(private http: HttpClient) { }


  getPrezzoCamere( checkinDate : string, checkoutDate : string, servizio : string,): Observable<number[]>{
    return this.http.get<number[]>(`${this.url}/getPrezzoCamera?date1=${checkinDate}&date2=${checkoutDate}&servizio=${servizio}`, { withCredentials: true })
}


prezzoPacchetto(id : number){
  this.getPrezzoPacch(id).subscribe(
    re => {
      this.prezzoPacch = re
    }
  )
}
  getPrezzoPacch(id : number) : Observable<number>{
    console.log("chaiamta getPrezzoPacch")
    return this.http.get<number>(`${this.url}/getPrezzoPacchetto?id=${id}`, { withCredentials: true })
  }

  
  getPrezziStagione() : Observable<Prezzo []>{
    return this.http.get<Prezzo []>(`${this.url}/getPrezziStagioni`, { withCredentials: true })
  }




  updatePrezzoStagione(servizio : string, costo : number, sconto : number){
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    
    console.log("dentro save cliente")
    let params = new HttpParams()
    .set('servizio', servizio)
    .set('costo', costo.toString())
    .set('sconto', sconto.toString())


  // Chiamata HTTP POST
  return this.http.post<string>(`${this.url}/updatePrezzo`, null, { headers, params, responseType: 'text' as 'json' });
  }
  
}
