import { TestBed } from '@angular/core/testing';

import { CamereDispServiceService } from './camere-disp-service.service';

describe('CamereDispServiceService', () => {
  let service: CamereDispServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CamereDispServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
