import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthServiceService } from '../auth-service/auth-service.service';
import { Observable } from 'rxjs';
import { newPrenotazione, Prenotazione, Utente } from '../../model/model';

@Injectable({
  providedIn: 'root'
})
export class CamereDispServiceService {

  doppie = 0;
  singole = 0;
  prenotazione!: Prenotazione; 
  emailUtente = ""

  private url : string = "http://localhost:8080";


  constructor(private http: HttpClient, private auth:AuthServiceService) { }

  

  camereDisponibili(checkinDate : string, checkoutDate: string): Observable <number[]>{
    return this.http.get<number[]>(`${this.url}/camereDisp?date1=${checkinDate}&date2=${checkoutDate}`, { withCredentials: true })
    
  }



  getDoppie(guests : number, rooms: number) : number{
    this.doppie = 0;
     while (guests > rooms){
      this.doppie += 1
      guests -= 2
      rooms -= 1
      console.log("Camere " + rooms)
      console.log("DOppie " + this.doppie)
     }
     return this.doppie
  }

  getSingole( rooms: number, doppie: number){
    this.singole = 0
    this.singole = rooms-doppie
    return this.singole
  }

  

}