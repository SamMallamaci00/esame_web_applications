import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Agenzia, newPrenotazione, Prenotazione, Utente } from '../../model/model';
import { Observable } from 'rxjs';
import { AuthServiceService } from '../auth-service/auth-service.service';
import { CamereDispServiceService } from '../camere-disp-service/camere-disp-service.service';
import { PrezzoServiceService } from '../prezzo-service/prezzo-service.service';
import { forkJoin } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class PrenotaServiceService {

  camere = 0
  private url = "http://localhost:8080";
  emailUtente = "";
  utente : Utente | undefined
  camereLibere : number[] | undefined 
  prezzo : number | undefined
  tipoPren = "camera"
  
  constructor(private http: HttpClient, private auth:AuthServiceService, private cameraDipService: CamereDispServiceService, private prezzoService : PrezzoServiceService,
              private router : Router, private route : ActivatedRoute
  ) { }


  creaPrenotazione(id:number, prezzoTot:number, utente:Utente, tipo:string, data_inizio:string, data_fine:string, camera: number){
    return newPrenotazione(id, prezzoTot, utente, tipo, data_inizio, data_fine, camera)
  }

  tipoPrenotazione(): void{
 if (this.router.url.includes(`/pacchetti-turistici/`)){
  this.tipoPren = "pacchetto"
  
 }

  }

  prezzoPren(){

  }

  prenota(checkinDate: string, checkoutDate: string, singole :number, doppie :number, prezzo_singole : number, prezzo_doppie : number ) {

    
   
    this.camere = this.cameraDipService.singole + this.cameraDipService.doppie
    this.emailUtente = this.auth.email;
    console.log("email " + this.emailUtente);
    console.log("camere " + this.camere);


        // Avvia le richieste asincrone per ogni iterazione
        const utenteObservable = this.findUtente(this.emailUtente);
        const camereLibereObservable = this.cameraDipService.camereDisponibili(checkinDate, checkoutDate);
        //const prezzoObservable = this.prezzoService.getPrezzo("singola_bassa");


        // Usa forkJoin per attendere che tutte le richieste siano completate
        forkJoin([utenteObservable, camereLibereObservable,]).subscribe(
          ([utente, camereLibere]) => {
              // Log dei dati per il debug
              console.log("Utente:", utente);
              console.log("Check-in Date:", checkinDate);
              console.log("Check-out Date:", checkoutDate);
              console.log("Camera Libera:", camereLibere);
      
              this.utente = utente;
              this.camereLibere = camereLibere;
              
      
              // Verifica la presenza di dati
              if (this.utente && checkinDate && checkoutDate && (this.camereLibere )) {
                for (let r = camereLibere[0]; r <= camereLibere[this.camere - 1]; r++ ){
                  console.log("Elementi che servono: " + r)


                  if (this.router.url.includes(`/pacchetti-turistici/`) && singole > 0){
                      this.prenotaServer(checkinDate, checkoutDate, this.auth.email, r, prezzo_singole, "singola_pacchetto").subscribe(
                          response => {
                              ("Prenotazione avvenuta con successo per camera " + response);
                          },
                          error => {
                              console.error("Errore nella prenotazione per camera ", error);
                          }
                      )
                      singole -=1
                      ;}
                    else if (this.router.url.includes(`/pacchetti-turistici/`) && doppie > 0){
                      this.prenotaServer(checkinDate, checkoutDate, this.auth.email, r, prezzo_doppie, "doppia_pacchetto").subscribe(
                          response => {
                              ("Prenotazione avvenuta con successo per camera " + response);
                          },
                          error => {
                              console.error("Errore nella prenotazione per camera ", error);
                          }
                      )
                      doppie -=1
                    ;} else if (singole > 0){
                        this.prenotaServer(checkinDate, checkoutDate, this.auth.email, r, prezzo_singole, "singola").subscribe(
                            response => {
                                ("Prenotazione avvenuta con successo per camera " + response);
                            },
                            error => {
                                console.error("Errore nella prenotazione per camera ", error);
                            }
                        )
                        singole -=1
                        ;} 
                         else if (doppie > 0){
                          this.prenotaServer(checkinDate, checkoutDate, this.auth.email, r, prezzo_doppie, "doppia").subscribe(
                              response => {
                                  ("Prenotazione avvenuta con successo per camera " + response);
                              },
                              error => {
                                  console.error("Errore nella prenotazione per camera ", error);
                              }
                          )
                          doppie -=1
                        }
                  
              }} else {
                  console.error("Dati mancanti per creare la prenotazione");
                  console.error("Dati disponibili:", {
                      utente: this.utente,
                      checkinDate: checkinDate,
                      checkoutDate: checkoutDate,
                      cameraLibera: this.camereLibere,
                      prezzo: this.prezzo
              });
                }
          },
          error => {
              console.error("Errore nel recuperare dati: ", error);
          }
      );
    }


prenotaPacchetto(checkinDate: string, checkoutDate: string, singole :number, doppie :number, prezzo: number, agenziaId : number){

      let prezzo_camere= prezzo
      
      console.log("dentro prenota pacchetto")
    



      console.log("id agenzia: " + agenziaId)
    
     
      this.camere = this.cameraDipService.singole + this.cameraDipService.doppie
      this.emailUtente = this.auth.email;
      console.log("email " + this.emailUtente);
      console.log("camere " + this.camere);
  


  
          // Avvia le richieste asincrone per ogni iterazione
          const utenteObservable = this.findUtente(this.emailUtente);
          const agenziaObservable = this.getAgenziaId(agenziaId);

          const camereLibereObservable = this.cameraDipService.camereDisponibili(checkinDate, checkoutDate);

          //const prezzoObservable = this.prezzoService.getPrezzo("singola_bassa");
  
  
          // Usa forkJoin per attendere che tutte le richieste siano completate
          forkJoin([utenteObservable, camereLibereObservable, agenziaObservable]).subscribe(
            ([utente, camereLibere, agenziaTrovata]) => {
                // Log dei dati per il debug
                console.log("Utente:", utente);
                console.log("Check-in Date:", checkinDate);
                console.log("Check-out Date:", checkoutDate);
                console.log("Camera Libera:", camereLibere);
        
                this.utente = utente;
                this.camereLibere = camereLibere;
                let agenzia : Agenzia = agenziaTrovata
                
        
                // Verifica la presenza di dati
                if (this.utente && checkinDate && checkoutDate && (this.camereLibere )) {
                  for (let r = camereLibere[0]; r <= camereLibere[this.camere - 1]; r++ ){
                    
                    if (singole > 0){
                        this.prenotaServer(checkinDate, checkoutDate, this.auth.email, r, prezzo_camere, "singola_pacchetto_" + agenziaTrovata.utente.cognome).subscribe(
                            response => {
                                ("Prenotazione avvenuta con successo per camera " + response);
                            },
                            error => {
                                console.error("Errore nella prenotazione per camera ", error);
                            }
                        )
                        singole -=1
                        ;}
                      else if (doppie > 0){
                        this.prenotaServer(checkinDate, checkoutDate, this.auth.email, r, prezzo_camere, "doppia_pacchetto" + agenziaTrovata.utente.cognome).subscribe(
                            response => {
                                ("Prenotazione avvenuta con successo per camera " + response);
                            },
                            error => {
                                console.error("Errore nella prenotazione per camera ", error);
                            }
                        )
                        doppie -=1
                      ;} 
                    
                }} else {
                    console.error("Dati mancanti per creare la prenotazione");
                    console.error("Dati disponibili:", {
                        utente: this.utente,
                        checkinDate: checkinDate,
                        checkoutDate: checkoutDate,
                        cameraLibera: this.camereLibere,
                        prezzo: this.prezzo
                });
                  }
            },
            error => {
                console.error("Errore nel recuperare dati: ", error);
            }
        );
      }

  findUtente(email : string): Observable<Utente>{
    return  this.http.get<Utente>(`${this.url}/getUtente?email=${email}`, { withCredentials: true })
  }

  getAgenziaId(id : number) : Observable <Agenzia>{

    return this.http.get<Agenzia>(`${this.url}/getAgenziaWithId?id=${id}`, {withCredentials: true });
  }

  prenotaServer(checkinDate: string, checkoutDate : string, utente: string, room: number, prezzo:number, tipo:string): Observable <String>{
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    
    return this.http.post<string>(`${this.url}/addPrenotazione?date1=${checkinDate}&date2=${checkoutDate}&utente=${utente}&room=${room}&prezzo=${prezzo}&tipo=${tipo}`, null, { headers: headers, responseType: 'text' as 'json' })
}
 
}
