import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Recensione } from '../../model/model';

@Injectable({
  providedIn: 'root'
})
export class RecensioniServiceService {

  private url = "http://localhost:8080";


  constructor(private http: HttpClient) { }


 
  saveRecensione(id: number, utente : string, titolo: string, testo:string, valutazione:number): Observable<String>{
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    console.log("dentro saveREcesnione service, valutazione: " + valutazione)
    
    let params = new HttpParams()
    .set('utente', utente)
    .set('titolo', titolo)
    .set('testo',testo)
    .set('valutazione', valutazione.toString());

  // Chiamata HTTP POST
  return this.http.post<String>(`${this.url}/addRecensione`, null, { headers, params, responseType: 'text' as 'json' });
  }

  getRecensioni(): Observable <Recensione[]>{
    return this.http.get<Recensione[]>(`${this.url}/getRecensioni`, {withCredentials: true});
  }
}
