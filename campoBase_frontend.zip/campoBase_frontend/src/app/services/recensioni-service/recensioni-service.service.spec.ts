import { TestBed } from '@angular/core/testing';

import { RecensioniServiceService } from './recensioni-service.service';

describe('RecensioniServiceService', () => {
  let service: RecensioniServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecensioniServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
