import { Injectable } from '@angular/core';
import { Agenzia, Pacchetto } from '../../model/model';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, ObservedValueOf } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgenzieServiceService {

  private url = "http://localhost:8080";

  agenzia : Agenzia | undefined 
  pacchetti : Pacchetto[] | undefined

  agenziaId = 0


  constructor(private http: HttpClient) { }


  getAgenzia(email : string) : Observable <Agenzia>{

    return this.http.get<Agenzia>(`${this.url}/getAgenzia?agenzia=${email}`, {withCredentials: true });
  }

  getAgenziaId(id : number) : Observable <Agenzia>{

    return this.http.get<Agenzia>(`${this.url}/getAgenziaWithId?id=${id}`, {withCredentials: true });
  }

  getInfoAgenzia(email : string) : Observable<String>{
    return this.http.get<string>(`${this.url}/getInfo?agenzia=${email}`, {withCredentials: true, responseType: 'text' as 'json' });
  }

  saveInfoAgenzia(id : number, info : string, logo : string, agenzia : string) : Observable<String>{

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

 
    const formData = new FormData();

    formData.append('id', id.toString());
    formData.append('info', info);
    formData.append('utente', agenzia);
    formData.append('logo', logo);

    


    

  // Chiamata HTTP POST
  return this.http.post<String>(`${this.url}/updateAgenzia`, formData, {responseType: 'text' as 'json' });
  }

  aggiungiPacchetto(id :number, agenzia : string, descrizione : string, prezzo : number) : Observable <String>{

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

 
    console.log("dentro save cliente")
    let params = new HttpParams()
    .set('id', id.toString())
    .set('descrizione', descrizione)
    .set('agenzia', agenzia)
    .set('prezzo', prezzo.toString());

  // Chiamata HTTP POST
  return this.http.post<String>(`${this.url}/addPacchetto`, null, { headers, params, responseType: 'text' as 'json' });
  }


  getPacchettiAgenzia(email: String) : Observable<Pacchetto[]>{
    return this.http.get<Pacchetto[]>(`${this.url}/getPacchettiAgenzia`, {withCredentials: true});
  }

  getAgenzie() : Observable <Agenzia[]>{
    return this.http.get<Agenzia[]>(`${this.url}/getAgenzie`, {withCredentials: true});
  }

  saveAgenzia(info : string, agenzia : string , logo: Uint8Array){
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

 
    const formData = new FormData();

    // Aggiungi i campi di testo
    formData.append('id', "null");
    formData.append('agenzia', agenzia);
    formData.append('info', info);

    // Aggiungi l'immagine come Blob
    const blob = new Blob([logo], { type: 'image/jpeg' });  // Usa il tipo MIME appropriato
    formData.append('logo', blob, 'pacchetto.jpg');  // Puoi dare un nome qualsiasi al file

  // Chiamata HTTP POST
  return this.http.post<String>(`${this.url}/saveAgenzia`, formData, {responseType: 'text' as 'json' });
}

deleteAgenzia(id: number): Observable<String>{
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

return this.http.post<string>(`${this.url}/deleteAgenzia?id=${id}`, null, { headers, responseType: 'text' as 'json' });
}

  
}
