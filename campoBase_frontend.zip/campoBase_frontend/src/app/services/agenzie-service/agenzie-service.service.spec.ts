import { TestBed } from '@angular/core/testing';

import { AgenzieServiceService } from './agenzie-service.service';

describe('AgenzieServiceService', () => {
  let service: AgenzieServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgenzieServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
