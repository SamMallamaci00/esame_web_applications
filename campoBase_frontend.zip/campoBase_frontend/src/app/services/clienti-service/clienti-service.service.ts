import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cliente } from '../../model/model';

@Injectable({
  providedIn: 'root'
})
export class ClientiServiceService {

  
  private url = "http://localhost:8080";


  constructor(private http: HttpClient) { }


  getClienti() : Observable <Cliente[]>{

    return this.http.get<Cliente []>(`${this.url}/getClienti`, {withCredentials: true});
  }

  saveCliente(id: number, utente : string, autorizzato: boolean): Observable<String>{
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    
    console.log("dentro save cliente")
    let params = new HttpParams()
    .set('id', id.toString())
    .set('utente', utente)
    .set('autorizzato', autorizzato.toString());

  // Chiamata HTTP POST
  return this.http.post<string>(`${this.url}/addCliente`, null, { headers, params, responseType: 'text' as 'json' });
  }

  newAdmin(email : string, ruolo: string): Observable<String>{
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    
    console.log("dentro save cliente")
    let params = new HttpParams()
    .set('email', email)
    .set('ruolo', ruolo)

  // Chiamata HTTP POST
  return this.http.post<string>(`${this.url}/newAdmin`, null, { headers, params, responseType: 'text' as 'json' });
  }

  getCliente(email : string): Observable <Cliente>{
    return this.http.get<Cliente>(`${this.url}/getCliente?email=${email}`, {withCredentials: true});
  }

  deleteCliente(id: number): Observable<String>{
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
  return this.http.post<string>(`${this.url}/deleteCliente?id=${id}`, null, { headers, responseType: 'text' as 'json' });
  }


}
