import exp from "constants"
import { ClientRequest } from "http"

export interface UtenteLogin{
    email:string
    password : string
}

export interface Utente{
    email:string
    password : string
    nome: string
    cognome: string
    ruolo: string

}

export interface Camera{
    id:number
}

export function newCamera (id:number) {
    return {
        id:id
    }
}




export function newUtenteSAve (email:string, password : string, nome:string, cognome : string, ruolo:string)
    {
        return{
       email:email,
       password:password,
       nome:nome,
       cognome:cognome,
       ruolo:ruolo

    }
    
}

export function newPrenotazione(
    id: number,
    prezzoTot: number,
    utente: Utente,
    tipo: string,
    data_inizio: string,
    data_fine: string,
    camera: number
): Prenotazione {
    return {
        id: id,
        prezzoTot: prezzoTot,
        utente: utente,
        tipo: tipo,
        data_inizio: data_inizio,
        data_fine: data_fine,
        camera: camera
    };
}

export interface AuthToken{
    token:string
} 

export interface Prenotazione{
    id:number
    prezzoTot:number
    utente:Utente
    tipo:string
    data_inizio:string
    data_fine:string
    camera: number
    
}

export interface Cliente{
    id : number
    utente : Utente
    autorizzato : boolean

}

export interface Agenzia{

    id : number
    utente : Utente
    info : string
    logo: string;
    pacchetti : Pacchetto []

}


export interface Pacchetto {
    id: number;
    agenzia: Agenzia;
    prezzo: number;
    descrizione: string;
    immagine: string;  
    titolo:string
}


export interface Recensione{

    id:number
    utente:Utente
    
    titolo:string
    testo_rec:string
    valutazione:number
}

export interface Prezzo{
    servizio : string;
    costo : number;
    sconto : number;

}

