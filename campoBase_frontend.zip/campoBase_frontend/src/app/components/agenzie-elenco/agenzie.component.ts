import { Component, OnInit } from '@angular/core';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';
import { Agenzia } from '../../model/model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agenzie',
  templateUrl: './agenzie.component.html',
  styleUrl: './agenzie.component.css'
})
export class AgenzieComponent implements OnInit{

  agenzie : Agenzia[] | undefined


  constructor(private agenziaServ : AgenzieServiceService, private router : Router){}

  ngOnInit(): void {

    this.agenziaServ.getAgenzie().subscribe(
    rec => {
      this.agenzie = rec

    }
      
    )
      
    }

    pacchetti(id : number){
      this.router.navigate([`area-riservata-admin/${id}/pacchetti`]);
  
    }

    delete(id:number){
      this.agenziaServ.deleteAgenzia(id).subscribe(
        rec=>{
          this.agenzie = this.agenzie?.filter(agenzia => agenzia.id !== id);
          console.log("Pacchetto eliminato")
        } , error =>{
          console.error("Errore durante l'eliminazione:", error);
    
        }
      )
    }

}
