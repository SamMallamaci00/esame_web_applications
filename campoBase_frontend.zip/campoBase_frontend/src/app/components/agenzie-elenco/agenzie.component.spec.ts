import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgenzieComponent } from './agenzie.component';

describe('AgenzieComponent', () => {
  let component: AgenzieComponent;
  let fixture: ComponentFixture<AgenzieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AgenzieComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AgenzieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
