import { Component } from '@angular/core';
import { Agenzia } from '../../model/model';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';

@Component({
  selector: 'app-aggiungi-agenzia',
  templateUrl: './aggiungi-agenzia.component.html',
  styleUrl: './aggiungi-agenzia.component.css'
})
export class AggiungiAgenziaComponent {
  logo : any ;
  info : string = ""
  agenzia = this.authServ.email


constructor(private authServ : AuthServiceService, private agenziaServ: AgenzieServiceService){}

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    if (file) {
      const reader = new FileReader();
  
      reader.onload = (e: any) => {
        let base64String = e.target.result;
        
        // Rimuovi la parte iniziale "data:image/jpeg;base64,"
        if (base64String.startsWith("data:image/jpeg;base64,")) {
          base64String = base64String.replace("data:image/jpeg;base64,", "");
        }
  
        // Imposta la stringa Base64 pulita come immagine
        this.logo = base64String;
      };
  
      reader.readAsDataURL(file); // Legge il file come DataURL
    }
}



saveAgenzia(){
  this.agenziaServ.saveAgenzia(this.info, this.agenzia, this.logo).subscribe(rec => {
    if (rec){
      console.log("Modifica avvenuta con successo")
    }else{
      console.log("Errore nella modifica")
    }
  }

  )
}
}

