import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AggiungiAgenziaComponent } from './aggiungi-agenzia.component';

describe('AggiungiAgenziaComponent', () => {
  let component: AggiungiAgenziaComponent;
  let fixture: ComponentFixture<AggiungiAgenziaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AggiungiAgenziaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AggiungiAgenziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
