import { Component, OnInit } from '@angular/core';
import { CamereDispServiceService } from '../../services/camere-disp-service/camere-disp-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { PrenotaServiceService } from '../../services/prenota-service/prenota-service.service';
import { of, concat, forkJoin } from 'rxjs'; // Per creare osservabili e concatenarle
import { concatMap } from 'rxjs/operators'; // Per eseguire le operazioni in sequenza
import { PrezzoServiceService } from '../../services/prezzo-service/prezzo-service.service';
@Component({
  selector: 'app-camere-disp',
  templateUrl: './camere-disp.component.html',
  styleUrl: './camere-disp.component.css'
})
export class CamereDispComponent implements OnInit{
handlePrezzoSingola($event: number) {
throw new Error('Method not implemented.');
}

  
  camere_disp : number[] | undefined;
  doppie = 0;
  singole = 0;
  prezzo = 0
  camere_richieste = 0;
  disponibile = false;


  prezzo_singole_con_sconto = 0;
  prezzo_singole_senza_sconto = 0;
  prezzo_singole = 0;

  prezzo_doppie_con_sconto = 0;
  prezzo_doppie_senza_sconto = 0;
  prezzo_doppie = 0;


  constructor(private camereService :CamereDispServiceService, private route:ActivatedRoute, private authService: AuthServiceService, 
              private prenotaService : PrenotaServiceService, private prezzoService : PrezzoServiceService, private router : Router){
                
                  console.log('CamereDispComponent constructor');
                
                
              }
    
  ngOnInit(): void {
    
    console.log("ngoninit")
    
    this.route.queryParamMap.subscribe(params => {
      // Ricaricare i dati quando i parametri di query cambiano
      this.caricaDati();

    });
  
    
  }
  
  caricaDati(): void {

    this.camere_disp = [];
    this.prezzo = 0;


  

  
    const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
    const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');
    const rooms = this.route.snapshot.queryParamMap.get('rooms');
    const guests = this.route.snapshot.queryParamMap.get('guests');

    console.log("checkin: " + checkinDate + " checkout: " + checkoutDate + " rooms: "+ rooms + " guests: " + guests)

    

  
    if (checkinDate && checkoutDate && rooms && guests){
      this.camere_richieste = parseInt(rooms);
      this.doppie = this.camereService.getDoppie(parseInt(guests), parseInt(rooms))
      this.singole = this.camereService.getSingole(parseInt(rooms), this.doppie)
    

      console.log("Singole " + this.singole)
      console.log("Doppie " + this.doppie)
      console.log("Camere richieste " + this.camere_richieste)


        this.camereService.camereDisponibili(checkinDate,checkoutDate).subscribe(
          rec => {console.log("Camere disponibili: " + rec.length)
              if(rec.length>0 && rec.length >= this.camere_richieste && rec.length <=8){
                this.disponibile = true;
              }
            }
          
        )

    }


  }


  clickPrenota() {
    if(!this.isAuthenticated()){
    return; // Termina l'esecuzione della funzione
    }
else{
    const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
    const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');


    if(checkinDate && checkoutDate){
    
        
        this.prenotaService.prenota(checkinDate, checkoutDate, this.singole, this.doppie, this.prezzo_singole, this.prezzo_doppie)
        
    }

}
  }
  handleDataFromCardSingole(prezzi: number []) {
      this.prezzo_singole_con_sconto = prezzi[1];
      this.prezzo_singole_senza_sconto = prezzi[0];

      console.log('Dati ricevuti dal figlio:', prezzi);
    }

    handleDataFromCardDoppie(prezzi: number []) {
      this.prezzo_doppie_con_sconto = prezzi[1];
      this.prezzo_doppie_senza_sconto = prezzi[0];
      console.log('Dati ricevuti dal figlio:', prezzi);
    }

 

  
  isAuthenticated(): boolean{
    return this.authService.isAuthenticated()
  }

  prezzoSingole(){
    if(this.prezzo_singole_con_sconto != 0 && this.prezzo_singole_con_sconto != this.prezzo_singole_senza_sconto){
      this.prezzo_singole = this.prezzo_singole_con_sconto
    }else{
      this.prezzo_singole = this.prezzo_singole_senza_sconto
    }
  }

  prezzoDoppie(){
    if(this.prezzo_doppie_con_sconto != 0 && this.prezzo_doppie_con_sconto != this.prezzo_doppie_senza_sconto){
      this.prezzo_doppie = this.prezzo_doppie_con_sconto
    }else{
      this.prezzo_doppie = this.prezzo_doppie_senza_sconto
    }
  }

  calcolaTotale(){
    this.prezzoSingole()
    this.prezzoDoppie()
    return this.prezzo_singole + this.prezzo_doppie
  }

 }
  

