import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CamereDispComponent } from './camere-disp.component';

describe('CamereDispComponent', () => {
  let component: CamereDispComponent;
  let fixture: ComponentFixture<CamereDispComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CamereDispComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CamereDispComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
