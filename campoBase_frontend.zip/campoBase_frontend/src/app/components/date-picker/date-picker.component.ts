import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrl: './date-picker.component.css'
})
export class DatePickerComponent implements OnInit{
  checkinDate: Date | any
  checkoutDate: Date | any
  guests: number | any
  rooms: number | any

  todayDate: string = "";



constructor(private router : Router, private route: ActivatedRoute, private agenziaServ : AgenzieServiceService){}




  ngOnInit(): void {
    

    this.route.queryParamMap.subscribe(params => {

      const today = new Date();
    this.todayDate = today.toISOString().split('T')[0]; // Data odierna in formato YYYY-MM-DD




      const checkin = params.get('checkinDate');
      const checkout = params.get('checkoutDate');
      const guests = params.get('guests');
      const rooms = params.get('rooms');

      if (checkin) this.checkinDate = checkin;
      if (checkout) this.checkoutDate = checkout;
      if (guests) this.guests = +guests;
      if (rooms) this.rooms = +rooms;
  });
  }



search(e: Event){

  let baseUrl = ""
  if(this.router.url.includes('prenota/camere-disp/')){
    baseUrl = 'prenota/camere-disp/'
   }

  else  if (this.router.url.includes(`/pacchetti-turistici/`)) {

    const agenzia = this.route.snapshot.paramMap.get('agenzia');
    const idpacchetto = this.route.snapshot.paramMap.get('idpacchetto');

    if(agenzia){
      this.agenziaServ.agenziaId = parseInt(agenzia)
    }

    
    baseUrl = `${agenzia}/pacchetti-turistici/${idpacchetto}/prenota/`;
    }
    else{
      baseUrl = "prenota/camere-disp/"
    }


  this.router.navigate([baseUrl + this.checkinDate, this.checkoutDate, this.guests, this.rooms], 
    { queryParams: { checkinDate: this.checkinDate, checkoutDate: this.checkoutDate, guests: this.guests, rooms: this.rooms} })
  
}


calculateDefaultCheckoutDate(): string {
  const today = new Date(this.todayDate);
  today.setDate(today.getDate() + 30);
  return today.toISOString().split('T')[0];
}

// Calcola il massimo per il check-out (30 giorni dopo il check-in)
calculateMaxCheckoutDate(): string {
  if (!this.checkinDate) return this.calculateDefaultCheckoutDate();
  const checkin = new Date(this.checkinDate);
  checkin.setDate(checkin.getDate() + 30);
  return checkin.toISOString().split('T')[0];
}

// Aggiorna il minimo del check-out quando cambia il check-in
updateCheckoutMinDate(): void {
  if (this.checkinDate && new Date(this.checkoutDate) < new Date(this.checkinDate)) {
    this.checkoutDate = this.checkinDate; // Imposta il check-out uguale al check-in se è minore
  }
}



}