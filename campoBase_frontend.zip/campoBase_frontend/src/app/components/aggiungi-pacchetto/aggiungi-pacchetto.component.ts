import { Component } from '@angular/core';
import { AreaRiservataAgenziaComponent } from '../area-riservata-agenzia/area-riservata-agenzia.component';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { PacchettiService } from '../../services/pacchetti-service/pacchetti.service';

@Component({
  selector: 'app-aggiungi-pacchetto',
  templateUrl: './aggiungi-pacchetto.component.html',
  styleUrl: './aggiungi-pacchetto.component.css'
})
export class AggiungiPacchettoComponent {

  descrizione  = ""
  prezzo = 0
  agenzia = this.authServ.email
  titolo = ""
  
  immagine : any

  valid = false
  checked = false

  constructor(private authServ : AuthServiceService, private agenziaServ : AgenzieServiceService, private pacchServ: PacchettiService){}

  
  savePacchetto(descrizione : string, prezzo : number, immagine: string, titolo: string){

    this.isValid(prezzo, descrizione, immagine, titolo)


    if(this.valid)
{
    this.pacchServ.savePacchetto(1, this.agenzia, prezzo, descrizione,  immagine, titolo ).subscribe(
      rec => {
        if(rec){
          console.log("Aggiunta avvenuta con successo")
        }else{
          console.log("Errore nell'aggiunta")
        }

      }
    )
  
  }

  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    if (file) {
      const reader = new FileReader();
  
      reader.onload = (e: any) => {
        let base64String = e.target.result;
        
        // Rimuovi la parte iniziale "data:image/jpeg;base64,"
        if (base64String.startsWith("data:image/jpeg;base64,")) {
          base64String = base64String.replace("data:image/jpeg;base64,", "");
        }
  
        // Imposta la stringa Base64 pulita come immagine
        this.immagine = base64String;
      };
  
      reader.readAsDataURL(file); // Legge il file come DataURL
    }
}





  isValid(prezzo : number, descrizione: string,  immagine : string , titolo : string ){
    if(titolo == '' || descrizione =="" || prezzo == 0 || prezzo == null || immagine == null || immagine == ""){
      this.valid = false
      this.checked = true
      console.log("non valido")
  
    } else {
      this.valid = true
      this.checked = true
      console.log("valido")
    }
}
}
