import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AggiungiPacchettoComponent } from './aggiungi-pacchetto.component';

describe('AggiungiPacchettoComponent', () => {
  let component: AggiungiPacchettoComponent;
  let fixture: ComponentFixture<AggiungiPacchettoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AggiungiPacchettoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AggiungiPacchettoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
