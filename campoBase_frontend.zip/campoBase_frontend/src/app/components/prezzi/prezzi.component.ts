import { Component, OnInit } from '@angular/core';
import { Prezzo } from '../../model/model';
import { PrezzoServiceService } from '../../services/prezzo-service/prezzo-service.service';

@Component({
  selector: 'app-prezzi',
  templateUrl: './prezzi.component.html',
  styleUrl: './prezzi.component.css'
})
export class PrezziComponent implements OnInit {

  prezzi : Prezzo [] = []

  editingIndex: number | null = null;

  valid :boolean = false
  checked = false


  constructor (private prezzoServ : PrezzoServiceService,
){}


  ngOnInit(): void {
    this.prezzoServ.getPrezziStagione().subscribe(
    (response) => {
      this.prezzi = response
      console.log("servizio: " + this.prezzi[0].servizio)
    }
    );
  }
  

  updatePrezzo(servizio : string, costo : number, sconto : number){

    this.isValid(servizio, costo, sconto)
    if(this.valid){
    this.prezzoServ.updatePrezzoStagione(servizio, costo, sconto).subscribe(
      rec => {
        console.log("Modifica avvenuta con successo")
      }
    )}
    this.editingIndex = null;

  }

  startEditing(index: number) {
    this.editingIndex = index;
  }

  formatServizio(servizio: string): string {
    if (!servizio) return '';
    // Sostituire underscore con spazi e rendere la prima lettera maiuscola
    return servizio
      .toLowerCase()
      .replace(/_/g, ' ')
      .replace(/\b\w/g, (char) => char.toUpperCase());
  }


  isValid(servizo : string, costo : number, sconto : number){

    if(servizo == '' || costo == null || sconto == null || costo.toString() == "" || sconto.toString() == ""){
      this.valid = false
      this.checked = true
      console.log("non valido")
  
    } else {
      this.valid = true
      this.checked = true
      console.log("valido")
    }
      
  }


}
