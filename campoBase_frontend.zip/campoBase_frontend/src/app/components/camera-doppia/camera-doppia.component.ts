import { Component, EventEmitter, Output } from '@angular/core';
import { CamereDispServiceService } from '../../services/camere-disp-service/camere-disp-service.service';
import { PrezzoServiceService } from '../../services/prezzo-service/prezzo-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-camera-doppia',
  templateUrl: './camera-doppia.component.html',
  styleUrl: './camera-doppia.component.css'
})
export class CameraDoppiaComponent {

  prezzo = 0;
  doppie : number | undefined 
  pacchetti = false

  prezzo_con_sconto = 0
  prezzo_senza_sconto = 0


  constructor(private camereDisp : CamereDispServiceService, private prezzoService: PrezzoServiceService, private route: ActivatedRoute,
              private router : Router
  ){}
  ngOnInit(): void {
      
    this.route.queryParamMap.subscribe(params => {
      // Ricaricare i dati quando i parametri di query cambiano 
      const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
      const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');
      if (checkinDate && checkoutDate){
        this.caricaPrezzo(checkinDate, checkoutDate, "doppia");}
     
    });
    if (this.router.url.includes(`/pacchetti-turistici/`)){
      this.pacchetti = true
    }
  }

  @Output() sendData: EventEmitter<number []> = new EventEmitter();


  caricaPrezzo(checkinDate : string, checkoutDate : string, servizio : string ){
    this.prezzoService.getPrezzoCamere(checkinDate, checkoutDate, "doppia").subscribe(
      prezzi => {
        this.prezzo_con_sconto= prezzi[1]
        this.prezzo_senza_sconto= prezzi[0]
        this.doppie = this.camereDisp.doppie;
        this.sendData.emit(prezzi);
      }
    )
   
   

  }

}
