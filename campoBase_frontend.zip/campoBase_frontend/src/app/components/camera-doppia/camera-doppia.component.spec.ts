import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CameraDoppiaComponent } from './camera-doppia.component';

describe('CameraDoppiaComponent', () => {
  let component: CameraDoppiaComponent;
  let fixture: ComponentFixture<CameraDoppiaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CameraDoppiaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CameraDoppiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
