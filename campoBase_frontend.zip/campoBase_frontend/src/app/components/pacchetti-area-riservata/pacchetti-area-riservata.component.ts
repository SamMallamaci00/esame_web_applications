import { Component } from '@angular/core';
import { Pacchetto } from '../../model/model';
import { PacchettiService } from '../../services/pacchetti-service/pacchetti.service';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-pacchetti-area-riservata',
  templateUrl: './pacchetti-area-riservata.component.html',
  styleUrl: './pacchetti-area-riservata.component.css'
})
export class PacchettiAreaRiservataComponent {
  pacchetti : Pacchetto[] = []
  editingIndex: number | null = null;

  valid = false
  checked = false


  constructor(private pacchettiServ : PacchettiService, private authServ: AuthServiceService, private router : Router,
              private route : ActivatedRoute
  ){}


  ngOnInit(): void {
    if(this.router.url.includes('area-riservata-admin')){
      const idagenzia = this.route.snapshot.paramMap.get('id');

      const id = idagenzia ? parseInt(idagenzia, 10) : NaN;
      this.pacchettiServ.getPacchettiId(id).subscribe(
        rec => {
          this.pacchetti = rec
        }
      )
    }else{
    this.pacchettiServ.getPacchettiAgenzia(this.authServ.email).subscribe(
      rec => {
        this.pacchetti = rec
      }
    )
  }
}
  


  startEditing(index: number) {
    this.editingIndex = index;
  }

save(id : number, agenzia: string , descrizione : string, prezzo : number, immagine: string, titolo:string) {
  

  this.isValid(titolo, descrizione, prezzo, immagine)
  if(this.valid){
  console.log("immagine: " + immagine)
  console.log("id: " + id)
  console.log("agenzia: " + agenzia)
  console.log("prezzo: " + prezzo)


  this.pacchettiServ.savePacchetto(id, agenzia, prezzo, descrizione, immagine, titolo).subscribe(rec => {
    if (rec){
      console.log("Modifica avvenuta con successo")

    }else[
      console.log("Errore nella modifica")
    ]
  }
)     }
else{

}  


}

isValid(titolo : string, descrizione : string, prezzo : number, immagine : string){
  if(titolo == '' || descrizione =="" || prezzo == 0 || prezzo == null || immagine == null || immagine == ""){
    this.valid = false
    this.checked = true
    console.log("non valido")

  } else {
    this.valid = true
    this.checked = true
    console.log("valido")
  }
    
}




// Funzione per gestire la selezione del file
onFileSelected(event: any, pacchetto: any) {
  const file: File = event.target.files[0];
  if (file) {
    const reader = new FileReader();

    reader.onload = (e: any) => {
      let base64String = e.target.result;
      
      // Rimuovi la parte iniziale "data:image/jpeg;base64,"
      if (base64String.startsWith("data:image/jpeg;base64,")) {
        base64String = base64String.replace("data:image/jpeg;base64,", "");
      }

      // Imposta la stringa Base64 pulita come immagine
      pacchetto.immagine = base64String;
      console.log(" dentro if immagine: "+  pacchetto.immagine)
      
    };


  reader.readAsDataURL(file); // Legge il file come DataURL
    
  }
}

delete(id:number){
  this.pacchettiServ.deletePacchetto(id).subscribe(
    rec=>{
      this.editingIndex = null;

      this.pacchetti = this.pacchetti?.filter(pacchetto => pacchetto.id !== id);
      console.log("Pacchetto eliminato")
    } , error =>{
      console.error("Errore durante l'eliminazione:", error);

    }
  )
}

}


