import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PacchettiAreaRiservataComponent } from './pacchetti-area-riservata.component';

describe('PacchettiAreaRiservataComponent', () => {
  let component: PacchettiAreaRiservataComponent;
  let fixture: ComponentFixture<PacchettiAreaRiservataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PacchettiAreaRiservataComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PacchettiAreaRiservataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
