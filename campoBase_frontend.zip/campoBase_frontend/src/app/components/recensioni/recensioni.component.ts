import { Component, OnInit } from '@angular/core';
import { Recensione } from '../../model/model';
import { RecensioniServiceService } from '../../services/recensioni-service/recensioni-service.service';

@Component({
  selector: 'app-recensioni',
  templateUrl: './recensioni.component.html',
  styleUrl: './recensioni.component.css'
})
export class RecensioniComponent implements OnInit{
  

  recensioni : Recensione [] = []


  constructor (private recService : RecensioniServiceService){}


  ngOnInit(): void {
      this.recService.getRecensioni().subscribe(
        rec =>{
          this.recensioni = rec
        }
      );
    }

    generateStars(valutazione: number): number[] {
      return Array(5).fill(0).map((_, i) => i < valutazione ? 1 : 0);
    }
    
    selectImage(valutazione : number) : string{
      if(valutazione == 1){
        return "assets/images/1_stella.jpg"
      } else if(valutazione == 2){
        return "assets/images/2_stelle.jpg"
      }else if(valutazione == 3){
        return "assets/images/3_stelle.jpg"
      }else if(valutazione == 4){
        return "assets/images/4_stelle.jpg"
      }else if(valutazione == 5){
        return "assets/images/5_stelle.jpg"
      } return ""
    }
  

}
