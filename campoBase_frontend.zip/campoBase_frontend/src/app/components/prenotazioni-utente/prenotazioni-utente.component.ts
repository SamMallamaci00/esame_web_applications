import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { Prenotazione } from '../../model/model';
import { PrenotazioniUtenteServiceService } from '../../services/prenotazioni-utente-service/prenotazioni-utente-service.service';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { GestisciPrenotazioniServiceService } from '../../services/gestisci-prenotazioni-service/gestisci-prenotazioni-service.service';


@Component({
  selector: 'app-prenotazioni-utente',
  templateUrl: './prenotazioni-utente.component.html',
  styleUrl: './prenotazioni-utente.component.css'
})
export class PrenotazioniUtenteComponent {

  private url = "http://localhost:8080";


  prenotazioni : Prenotazione [] = []
  email: string = "" ;
  ruolo : string = ""
  ;
  page: number = 1; // Pagina iniziale



  constructor(private prenService : PrenotazioniUtenteServiceService, private loginService: AuthServiceService, private http: HttpClient,
              private gestisciPrenServ : GestisciPrenotazioniServiceService
  ){}
  

  ngOnInit(){
      this.email = this.loginService.email
      console.log("dentro componente " + this.email)
          if (this.email) {
        this.prenService.getPrenotazioniUtente(this.email).subscribe(
          (rec: Prenotazione[]) => {
            if (rec) {
              this.prenotazioni = rec;
            }
          }
        );
      } else {
        console.error("Email non è stata inizializzata correttamente.");
      }
    }

    delete(id : number){
      this.gestisciPrenServ.deletePrenotazione(id).subscribe(
        rec => {
          this.prenotazioni = this.prenotazioni?.filter(prenotazione => prenotazione.id !== id);
    
          console.log("Delete avvenuta con successo")
        }
    
      )
    
    }


    



}
