import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrenotazioniUtenteComponent } from './prenotazioni-utente.component';

describe('PrenotazioniUtenteComponent', () => {
  let component: PrenotazioniUtenteComponent;
  let fixture: ComponentFixture<PrenotazioniUtenteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PrenotazioniUtenteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PrenotazioniUtenteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
