import { Component, OnInit } from '@angular/core';
import { Cliente, Utente } from '../../model/model';
import { ClientiServiceService } from '../../services/clienti-service/clienti-service.service';

@Component({
  selector: 'app-clienti',
  templateUrl: './clienti.component.html',
  styleUrl: './clienti.component.css'
})
export class ClientiComponent implements OnInit{
  
  clienti ?: Cliente []
  isEditing: boolean | undefined;

  isCheckboxDisabled = true

  constructor(private clientiServ : ClientiServiceService){}


  ngOnInit(): void {

    this.clientiServ.getClienti().subscribe(
    rec => {
      this.clienti = rec
    

    }
      
    )
      
    }


    editingIndex: number | null = null;

  startEditing(index: number) {
    this.isEditing = true
    this.editingIndex = index;
  }

  save(id: number, utente : string, autorizzato : boolean){
    this.editingIndex = null
    this.clientiServ.saveCliente(id, utente, autorizzato ).subscribe(
      rec =>{
        console.log("Modifica avvenuta con successo")
      }
    )
    this.editingIndex = null

}

newAdmin(email : string , ruolo : string){
  this.editingIndex = null
  this.clientiServ.newAdmin(email, ruolo).subscribe(
    (responde) =>{
      this.clienti = this.clienti?.filter(cliente => cliente.utente.email !== email);

      console.log("Modifica avvenuta con successo")
    }
  )
  this.editingIndex = null

}

delete(id : number){
  this.clientiServ.deleteCliente(id).subscribe(
    rec => {
      this.clienti = this.clienti?.filter(cliente => cliente.id !== id);

      console.log("Delete avvenuta con successo")
    }

  )
  this.editingIndex = null


}

}
