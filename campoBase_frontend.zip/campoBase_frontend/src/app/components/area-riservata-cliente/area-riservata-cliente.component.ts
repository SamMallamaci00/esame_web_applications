import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-area-riservata-cliente',
  templateUrl: './area-riservata-cliente.component.html',
  styleUrl: './area-riservata-cliente.component.css'
})
export class AreaRiservataClienteComponent {

constructor(private router : Router){}

  prenota(){
    this.router.navigate(['area-riservata-cliente/prenota'])
  }

  miePrenotazioni(){
    this.router.navigate(['area-riservata-cliente/prenotazioni-utente'])
    
  }

  aggiungiRecensione(){
    this.router.navigate(['area-riservata-cliente/aggiungi-recensione']);
  }

}
