import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import e from 'express';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { PrenotazioniUtenteServiceService } from '../../services/prenotazioni-utente-service/prenotazioni-utente-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  constructor(private router:Router, private authService : AuthServiceService, private prenService: PrenotazioniUtenteServiceService,
    private route:ActivatedRoute
  ){}
  

  email = ""
  password = ""
  ruolo = ""

 
  isMenuOpen = false;

  isModalOpen = false;



  areaRiservata() {
    this.isMenuOpen = !this.isMenuOpen;
    this.prenService.getRuolo(this.authService.email).subscribe(
      (rec: string) => {
        switch (rec) {
          case 'cliente':
            this.router.navigate(['area-riservata-cliente/prenotazioni-utente']);
            break;
          case 'admin':
            this.router.navigate(['area-riservata-admin/gestisci-prenotazioni']);
            break;
          case 'agenzia':
            this.router.navigate(['area-riservata-agenzia/le-tue-info']);
            break;
          default:
            console.error('Ruolo non riconosciuto:', rec);
        }this.openModal()
      },
      error => {
        
        console.error('Errore durante il recupero del ruolo:', error);
      }
    );
    this.handleMenuItemClick() 

     // Chiudi il menu dopo la navigazione
  }
  



  agenzieViaggi(){
    this.router.navigate(['agenzie-viaggi'])
    this.handleMenuItemClick() 

  }

  recensioni(){
     this.router.navigate(['cosa-dicono-di-noi'])
     this.handleMenuItemClick() 

  }


  login(e : Event){
    this.authService.login(this.email, this.password)

  }

  logout(){
  this.ruolo = ""
  console.log("Ruolo dopo login: "+this.ruolo)    
  this.authService.logout()
  }

  isAuthenticated(): boolean{
    return this.authService.isAuthenticated()
  }


  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen; // Cambia lo stato del menu
    const body = document.querySelector('body');
    
    if (this.isMenuOpen) {
      body?.classList.add('no-scroll');
      console.log('Classe no-scroll aggiunta');
    } else {
      body?.classList.remove('no-scroll');
      console.log('Classe no-scroll rimossa');
    }
  }
  

  openModal() {
   
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  handleMenuItemClick() {
    this.isMenuOpen = false; // Chiude il menu
    const menuToggle = document.getElementById('menuToggle') as HTMLInputElement;
    if (menuToggle) {
      menuToggle.checked = false; // Deseleziona il checkbox per riportare l'icona hamburger allo stato iniziale
    }
    
  }

}
