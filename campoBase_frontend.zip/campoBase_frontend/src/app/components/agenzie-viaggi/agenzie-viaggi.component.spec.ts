import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgenzieViaggiComponent } from './agenzie-viaggi.component';

describe('AgenzieViaggiComponent', () => {
  let component: AgenzieViaggiComponent;
  let fixture: ComponentFixture<AgenzieViaggiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AgenzieViaggiComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AgenzieViaggiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
