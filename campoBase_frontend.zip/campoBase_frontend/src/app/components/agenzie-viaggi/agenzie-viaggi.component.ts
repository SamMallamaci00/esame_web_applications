import { Component, OnInit } from '@angular/core';
import { Agenzia } from '../../model/model';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agenzie-viaggi',
  templateUrl: './agenzie-viaggi.component.html',
  styleUrl: './agenzie-viaggi.component.css'
})
export class AgenzieViaggiComponent implements OnInit{

  agenzie : Agenzia [] = []


  constructor(private agenziaServ : AgenzieServiceService, private router : Router){}


  ngOnInit(): void {
    this.agenziaServ.getAgenzie().subscribe(
      rec => {
        this.agenzie = rec
      }
    )
  }

  pacchetti(id : number){
    this.router.navigate([`${id}/pacchetti-turistici`]);

  }


}
