import { Component, OnInit } from '@angular/core';
import { Agenzia } from '../../model/model';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';
import { log } from 'node:console';

@Component({
  selector: 'app-info-agenzia',
  templateUrl: './info-agenzia.component.html',
  styleUrl: './info-agenzia.component.css'
})
export class InfoAgenziaComponent implements OnInit{

    agenzia = this.authServ.email;
    info = "";
    id = 0;
    editing = false;
    logo: any;

    valid = false
    checked = false
    
  
    constructor(private agenziaServ: AgenzieServiceService, private authServ: AuthServiceService) {}
  
    ngOnInit(): void {
      this.agenziaServ.getAgenzia(this.authServ.email).subscribe(
        rec => {
          console.log("info " + rec.info);
          console.log("id " + rec.id);
          console.log("logo on init " + rec.logo);
          this.info = rec.info;
          this.id = rec.id;
          this.logo = rec.logo; 
        }
      );
    }
  
    modificaInfo() {
      this.editing = true;
    }
  
    saveInfo(id: number, info: string) {
      console.log("logo " + this.logo)
      this.isValid()
      if(this.valid){
      this.agenziaServ.saveInfoAgenzia(id, info, this.logo, this.agenzia).subscribe(
        rec => {
          if (rec) {
            console.log("Modifica avvenuta con successo");
          } else {
            console.log("Errore nella modifica");
          }
        }
      );}
      else{

      }
      
    }
  
    onFileSelected(event: any) {
      const file: File = event.target.files[0];
      if (file) {
        const reader = new FileReader();
  
        reader.onload = (e: any) => {
          let base64String = e.target.result;
  
          // Rimuove la parte iniziale "data:image/jpeg;base64,"
          if (base64String.startsWith("data:image/jpeg;base64,")) {
            base64String = base64String.replace("data:image/jpeg;base64,", "");
          } else if (base64String.startsWith("data:image/png;base64,")) {
            base64String = base64String.replace("data:image/png;base64,", "");
          }
  
          // Imposta la stringa Base64 pulita come immagine
          this.logo = base64String;
          console.log("logo: " + this.logo);  // La stringa base64 verrà stampata qui
        };
  
        reader.readAsDataURL(file); // Legge il file come Data URL (base64)
      }
    }


    isValid(){
      if(this.info == '' || this.logo =="" || this.logo == null){
        this.valid = false
        this.checked = true
      } else {
        this.valid = true
        this.checked = true
      }
        
    }
  
  
}
