import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoAgenziaComponent } from './info-agenzia.component';

describe('InfoAgenziaComponent', () => {
  let component: InfoAgenziaComponent;
  let fixture: ComponentFixture<InfoAgenziaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InfoAgenziaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InfoAgenziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
