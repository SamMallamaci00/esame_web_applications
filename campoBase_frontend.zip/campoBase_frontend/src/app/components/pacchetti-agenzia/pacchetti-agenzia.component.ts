import { Component, EventEmitter, Output } from '@angular/core';
import { Pacchetto } from '../../model/model';
import { PacchettiService } from '../../services/pacchetti-service/pacchetti.service';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PrezzoServiceService } from '../../services/prezzo-service/prezzo-service.service';

@Component({
  selector: 'app-pacchetti-agenzia',
  templateUrl: './pacchetti-agenzia.component.html',
  styleUrl: './pacchetti-agenzia.component.css'
})
export class PacchettiAgenziaComponent {

  pacchetti : Pacchetto[] = []
  id : number = 0

  pacchettoId = "";

  prezzo = 0;

  numeroProva : number = 0

  expandedIndex: number | null = null;

  constructor(private pacchettiServ : PacchettiService, private authServ: AuthServiceService, private route: ActivatedRoute,
              private router : Router, private prezzoServ : PrezzoServiceService
  ){}


  @Output() sendPrezzo: EventEmitter<number> = new EventEmitter();
  @Output() sendId: EventEmitter<number> = new EventEmitter();




  ngOnInit(): void {
    // Sottoscrivi a paramMap per gestire sia il caricamento iniziale che gli aggiornamenti
    this.route.paramMap.subscribe(params => {
      const agenzia = params.get('agenzia');
      console.log('Parametro agenzia:', agenzia);

      if (agenzia) {
        this.id = parseInt(agenzia, 10); 
        this.caricaDati();
      } else {
        console.error('Parametro agenzia non trovato');
      }
    });
  }

  caricaDati(): void {

    /* PER UTILIZZO PROXY
    this.pacchettiServ.getPacchettiProxy(this.id).subscribe(
      rec => {
        this.pacchetti = rec;
      },
      error => {
        console.error('Errore durante il recupero dei pacchetti', error);
      }
    );*/
    this.pacchettiServ.getPacchettiId(this.id).subscribe(
      rec => {
        this.pacchetti = rec;
      },
      error => {
        console.error('Errore durante il recupero dei pacchetti', error);
      }
    );
  }

  disponibilitaPac(id : number, prezzo : number){
    this.pacchettoId = this.route.snapshot.paramMap.get('agenzia') || '';
    this.numeroProva = parseInt(this.pacchettoId)
    this.prezzo = prezzo
    console.log ("Id pacchetto: " + id)
    this.sendPrezzo.emit(this.prezzo)
    this.prezzoServ.prezzoPacchetto(id)
    this.router.navigate([`${this.numeroProva}/pacchetti-turistici`+ `/${id}/prenota`])
  }



  formatDescription(description: string, isExpanded: boolean): string {
    if (!description) return '';
    
    // Se il pacchetto è espanso, mostriamo la descrizione completa
    if (isExpanded) {
      return description
      .replace(/\n+/g, '<br>') // Sostituire ritorni a capo multipli con un singolo <br>
      .replace(/\s+/g, ' ');
    }
    
    // Mostra solo i primi 150 caratteri e aggiungi '...' se la descrizione è lunga
    return description.length > 150 ? description.substring(0, 150) + '...' : description;
  }
 

  
 

  // Gestisce il clic per espandere o comprimere la scheda
  toggleInfo(index: number): void {
    if (this.expandedIndex === index) {
      this.expandedIndex = null; // Comprimi la scheda se già espansa
    } else {
      this.expandedIndex = index; // Espandi la scheda cliccata
    }
  }
  
}
