import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PacchettiAgenziaComponent } from './pacchetti-agenzia.component';

describe('PacchettiAgenziaComponent', () => {
  let component: PacchettiAgenziaComponent;
  let fixture: ComponentFixture<PacchettiAgenziaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PacchettiAgenziaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PacchettiAgenziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
