import { Component } from '@angular/core';

@Component({
  selector: 'app-pacchetto',
  templateUrl: './pacchetto.component.html',
  styleUrl: './pacchetto.component.css'
})
export class PacchettoComponent {

}
