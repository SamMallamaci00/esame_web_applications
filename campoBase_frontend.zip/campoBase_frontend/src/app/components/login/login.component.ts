import { Component, EventEmitter, Output } from '@angular/core';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { FormsModule } from '@angular/forms';
import { Utente } from '../../model/model';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private authService : AuthServiceService){}

  email = ""
  password = ""
  isRegisterMode = false; // Modalità login iniziale


  nome=""
  cognome=""
  confirmPassword=""
  

  @Output() close = new EventEmitter<void>();


  login(e : Event){
    this.authService.login(this.email, this.password)
    this.close.emit(); // Chiude il modal al termine

  }

  toggleMode() {
    this.isRegisterMode = !this.isRegisterMode;
  }


  emailError = false;
passwordMismatchError = false;

registarti(e: Event) {
  e.preventDefault();

  // Reset degli errori
  this.emailError = false;
  this.passwordMismatchError = false;

  // Controllo validità email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(this.email)) {
    this.emailError = true;
    return;
  }

  // Controllo che la password e la conferma della password coincidano
  if (this.password !== this.confirmPassword) {
    this.passwordMismatchError = true;
    return;
  }

  const nuovoUtente: Utente = {
    email: this.email,
    password: this.password, // Idealmente, qui la password dovrebbe essere hashata
    nome: this.nome,
    cognome: this.cognome,
    ruolo: "cliente"
  };

  this.authService.registrazione(this.email, this.password, this.nome, this.cognome, "cliente").subscribe(
    rec => {
      if (rec) {
        console.log(rec);
      } else {
        console.log("Registrazione non riuscita");
      }
    }
  );
}

}
