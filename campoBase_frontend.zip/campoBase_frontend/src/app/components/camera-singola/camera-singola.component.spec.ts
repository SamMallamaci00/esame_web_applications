import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CameraSingolaComponent } from './camera-singola.component';

describe('CameraSingolaComponent', () => {
  let component: CameraSingolaComponent;
  let fixture: ComponentFixture<CameraSingolaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CameraSingolaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CameraSingolaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
