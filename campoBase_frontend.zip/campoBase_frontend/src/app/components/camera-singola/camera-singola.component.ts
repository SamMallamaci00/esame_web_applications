import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CamereDispServiceService } from '../../services/camere-disp-service/camere-disp-service.service';
import { PrezzoServiceService } from '../../services/prezzo-service/prezzo-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { send } from 'process';
import { PacchettoComponent } from '../pacchetto/pacchetto.component';

@Component({
  selector: 'app-camera-singola',
  templateUrl: './camera-singola.component.html',
  styleUrl: './camera-singola.component.css'
})
export class CameraSingolaComponent implements OnInit{
  prezzo_con_sconto = 0;
  prezzo_senza_sconto =  0;
  singole : number | undefined 
  pacchetti = false


  constructor(private camereDisp : CamereDispServiceService, private prezzoService: PrezzoServiceService, private route: ActivatedRoute,
              private router : Router
  ){}
  
  
  ngOnInit(): void {
      
    this.route.queryParamMap.subscribe(params => {
      // Ricaricare i dati quando i parametri di query cambiano 
      const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
      const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');
      if (checkinDate && checkoutDate){
        this.caricaPrezzo(checkinDate, checkoutDate, "singola");}
     
    });

    if (this.router.url.includes(`/pacchetti-turistici/`)){
      this.pacchetti = true
    }
  }

  @Output() sendData: EventEmitter<number []> = new EventEmitter();


  caricaPrezzo(checkinDate : string, checkoutDate : string, servizio : string ){
    this.prezzoService.getPrezzoCamere(checkinDate, checkoutDate, "singola").subscribe(
      prezzi => {
        this.prezzo_con_sconto= prezzi[1]
        this.prezzo_senza_sconto= prezzi[0]
        this.singole = this.camereDisp.singole;
        console.log("Singole: " + this.singole)
        this.sendData.emit(prezzi);
      }
    )
   


  }

 


}
