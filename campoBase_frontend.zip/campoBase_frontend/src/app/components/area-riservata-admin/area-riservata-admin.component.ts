import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-area-riservata-admin',
  templateUrl: './area-riservata-admin.component.html',
  styleUrl: './area-riservata-admin.component.css'
})
export class AreaRiservataAdminComponent {

  constructor(private router : Router){}


  gestisciPren(){
      this.router.navigate(['area-riservata-admin/gestisci-prenotazioni',])
    }

  clienti(){
    this.router.navigate(['area-riservata-admin/clienti',])
    //window.open('http://localhost:8080/dammiClienti');


  }

  agenzie(){
    this.router.navigate(['area-riservata-admin/agenzie',])

  }

  aggiungiUtente(){
    window.open('http://localhost:8080/aggiungiUtente');

    }

    prezzi(){
      this.router.navigate(['area-riservata-admin/prezzi',])
  
    }

    
  }




