import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PacchettiDispComponent } from './pacchetti-disp.component';

describe('PacchettiDispComponent', () => {
  let component: PacchettiDispComponent;
  let fixture: ComponentFixture<PacchettiDispComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PacchettiDispComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PacchettiDispComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
