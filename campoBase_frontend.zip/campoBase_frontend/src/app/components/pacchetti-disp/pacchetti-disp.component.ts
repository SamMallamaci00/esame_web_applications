import { Component, OnInit } from '@angular/core';
import { PacchettiService } from '../../services/pacchetti-service/pacchetti.service';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { CamereDispServiceService } from '../../services/camere-disp-service/camere-disp-service.service';
import { PrenotaServiceService } from '../../services/prenota-service/prenota-service.service';
import { ActivatedRoute } from '@angular/router';
import { PrezzoServiceService } from '../../services/prezzo-service/prezzo-service.service';
import { parse } from 'path';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';

@Component({
  selector: 'app-pacchetti-disp',
  templateUrl: './pacchetti-disp.component.html',
  styleUrl: './pacchetti-disp.component.css'
})
export class PacchettiDispComponent implements OnInit{


  camere_disp : number[] | undefined;
  doppie = 0;
  singole = 0;
  prezzo = 0
  camere_richieste = 0;
  disponibile = false;
  pacchetti = 0

  idPacchetto = 0

  constructor (private paccServ : PacchettiService, private authServ : AuthServiceService, private camereService : CamereDispServiceService,
                private prenotaServ : PrenotaServiceService, private route : ActivatedRoute, private prezzoServ : PrezzoServiceService,
                private agenziaServ: AgenzieServiceService
  ){}
  
  
  
    ngOnInit(): void {
    
      this.route.queryParamMap.subscribe(params => {
        // Ricaricare i dati quando i parametri di query cambiano
        this.caricaDati();
      });
    
      
    }
    
    caricaDati(): void {
  
      this.camere_disp = [];
      this.prezzo = this.prezzoServ.prezzoPacch;
  
  
      console.log("dentro carica dati")
  
      const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
      const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');
      const rooms = this.route.snapshot.queryParamMap.get('rooms');
      const guests = this.route.snapshot.queryParamMap.get('guests');
      this.route.parent?.params.subscribe(
        param =>{
          this.idPacchetto = param['idpacchetto'];
        }
      )

      console.log("checkinDate " + checkinDate)
      console.log("checkoutDate " + checkoutDate)
      console.log("rooms " + rooms)
      console.log("idPacchetto " + this.idPacchetto)
  
      
  
    
      if (checkinDate && checkoutDate && rooms && guests && this.idPacchetto){
        console.log("dentro primo if ")
        this.camere_richieste = parseInt(rooms);
        this.doppie = this.camereService.getDoppie(parseInt(guests), parseInt(rooms))
        this.singole = this.camereService.getSingole(parseInt(rooms), this.doppie)
        this.pacchetti = parseInt(guests)
      
  
        console.log("Singole " + this.singole)
        console.log("Doppie " + this.doppie)
        console.log("Camere richieste " + this.camere_richieste)
        console.log("PAcchetti " + this.pacchetti)

  
          this.camereService.camereDisponibili(checkinDate,checkoutDate).subscribe(
            rec => {console.log("Camere disponibili: " + rec.length)
                if(rec.length>0 && rec.length >= this.camere_richieste && rec.length <=8){
                  console.log("dentro secodno if")
                  this.disponibile = true;
                }
              }
            
          )
  
      }
}


clickPrenota() {
  if(!this.isAuthenticated()){
    alert('Devi accedere o registrarti per procedere con la prenotazione.');
  return; // Termina l'esecuzione della funzione
  }
  else{

  const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
  const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');

  console.log("prezzo: " + this.prezzo + " agenziaid: " + this.agenziaServ.agenziaId)



  if(checkinDate && checkoutDate){
      this.prenotaServ.prenotaPacchetto(checkinDate, checkoutDate, this.singole, this.doppie, this.prezzo, this.agenziaServ.agenziaId)
  }
}



}


isAuthenticated(): boolean{
  return this.authServ.isAuthenticated()
}

prezzoPacchetto(){
  this.prezzoServ.getPrezzoPacch(this.idPacchetto).subscribe(
    rec =>{
      this.prezzo = rec
    } 
  )
}

}


