import { Component } from '@angular/core';
import { GestisciPrenotazioniServiceService } from '../../services/gestisci-prenotazioni-service/gestisci-prenotazioni-service.service';
import { Prenotazione } from '../../model/model';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-gestisci-prenotazioni',
  templateUrl: './gestisci-prenotazioni.component.html',
  styleUrl: './gestisci-prenotazioni.component.css'
})
export class GestisciPrenotazioniComponent {
  
  
  prenotazioni : Prenotazione [] = []
  prenotazioniRicerca : Prenotazione [] = []
  prenotazioniFiltri : Prenotazione [] = []
  email: string = "" ;
  tipo : string = ""
  checkinDate : string  = ""
  checkoutDate : string  = ""
  nome: string = ""
  cognome : string = ""

  page: number = 1; // Ppagina iniziale
  itemsPerPage: number = 5; // Numero di prenotazioni per pagina



  constructor(private gestisciPrenServ : GestisciPrenotazioniServiceService, private http: HttpClient, private route : ActivatedRoute,
    private router : Router
  ){}
  

  ngOnInit(): void {
    // Carica le prenotazioni iniziali
    this.gestisciPrenServ.getPrenotazioni().subscribe(
      (rec: Prenotazione[]) => {
        if (rec) {
          this.prenotazioniRicerca = rec;
          // Subscrivi ai cambiamenti nei parametri della query dopo aver caricato le prenotazioni
          this.route.queryParamMap.subscribe(params => {
            this.email = params.get('email') || '';
            this.checkinDate = params.get('checkinDate') || '';
            this.checkoutDate = params.get('checkoutDate') || '';
            this.tipo = params.get('tipo') || '';
            // Ricarica i dati quando i parametri cambiano
            this.caricaDati();
          });
        } else {
          console.error("Errore.");
        }
      }
    );
  }
caricaDati(){



  const checkinDate = this.route.snapshot.queryParamMap.get('checkinDate');
  const checkoutDate = this.route.snapshot.queryParamMap.get('checkoutDate');
  const nome = this.route.snapshot.queryParamMap.get('nome');
  const cognome = this.route.snapshot.queryParamMap.get('cognome');
  const tipo = this.route.snapshot.queryParamMap.get('tipo');


if(this.prenotazioniRicerca){

  console.log("dentro carica dati")
  console.log("email " + this.email)


// Definizione delle variabili filtro
// Variabile per tenere traccia del tipo di filtro applicato
let filtroAttivo = 0;


if (this.tipo) filtroAttivo += 1;
if (this.nome && this.cognome) filtroAttivo += 2;
if (this.checkinDate) filtroAttivo += 4;
if (this.checkoutDate) filtroAttivo += 8;

switch (filtroAttivo) {
  case 0:
    // Nessun filtro applicato
    console.log("Nessun filtro applicato, eseguo la ricerca globale.");
    this.prenotazioni = this.prenotazioniRicerca;
    break;
  case 1:
    // Solo tipo
    console.log("Filtro per tipo applicato.");
    this.prenotazioni = this.prenotazioniRicerca.filter(p => p.tipo === this.tipo );
    break;
  case 2:
    // Solo email
    console.log("Filtro per nome e cognome.");
    this.prenotazioni = this.prenotazioniRicerca.filter(p => p.utente.nome === this.nome && p.utente.cognome === this.cognome);
    break;
  case 3:
    // Tipo e email
    console.log("Filtro per tipo e email applicati.");
    this.prenotazioni = this.prenotazioniRicerca.filter(p => p.tipo === this.tipo && p.utente.nome === this.nome && p.utente.cognome === this.cognome);
    break;
  case 4:
    // Solo checkinDate
    console.log("Filtro per checkinDate applicato.");
    this.prenotazioni = this.prenotazioniRicerca.filter(p => p.data_inizio === this.checkinDate);
    break;
  case 8:
    // Solo checkoutDate
    console.log("Filtro per checkoutDate applicato.");
    this.prenotazioni = this.prenotazioniRicerca.filter(p => p.data_fine === this.checkoutDate);
    break;
  case 12:
    // CheckinDate e checkoutDate
    console.log("Filtro per checkinDate e checkoutDate applicati.");
    if (this.checkinDate && this.checkoutDate) {
      this.prenotazioni = this.prenotazioniRicerca.filter(p => p.data_inizio >= this.checkinDate && p.data_fine <= this.checkoutDate);
    }
    break;
  case 14:
    // CheckinDate, checkoutDate e email
    console.log("Filtro per checkinDate, checkoutDate e email applicati.");
    if (this.checkinDate && this.checkoutDate) {
      this.prenotazioni = this.prenotazioniRicerca.filter(p => p.data_inizio >= this.checkinDate && p.data_fine <= this.checkoutDate && p.utente.nome === this.nome && p.utente.cognome === this.cognome);
    }
    break;
  case 13:
    // CheckinDate, checkoutDate e tipo
    console.log("Filtro per checkinDate, checkoutDate e tipo applicati.");
    if (this.checkinDate && this.checkoutDate) {
      this.prenotazioni = this.prenotazioniRicerca.filter(p => p.data_inizio >= this.checkinDate && p.data_fine <= this.checkoutDate && p.tipo === this.tipo);
    }
    break;
  case 15:
    // CheckinDate, checkoutDate, email e tipo
    console.log("Filtro per checkinDate, checkoutDate, email e tipo applicati.");
    if (this.checkinDate && this.checkoutDate) {
      this.prenotazioni = this.prenotazioniRicerca.filter(p => p.data_inizio >= this.checkinDate && p.data_fine <= this.checkoutDate && p.utente.nome === this.nome && p.utente.cognome === this.cognome && p.tipo === this.tipo);
    }
    break;
  default:
    // Caso generale per ricerche con più filtri
    console.log("Filtri multipli applicati.");
    this.prenotazioni = this.prenotazioniRicerca;
    break;
}
}
}

    



    applica(){
      if (this.nome && !this.cognome) {
        alert("Inserisci anche il cognome per effettuare la ricerca per nome e cognome.");
      } else if (!this.nome && this.cognome) {
        alert("Inserisci anche il nome per effettuare la ricerca per nome e cognome.");
      }else{
      this.router.navigate(['area-riservata-admin/gestisci-prenotazioni', this.nome, this.cognome, this.checkinDate, this.checkoutDate, this.tipo], 
        { queryParams: {nome: this.nome, cognome: this.cognome, checkinDate: this.checkinDate, checkoutDate: this.checkoutDate, tipo: this.tipo} })
    }
  }


  delete(id : number){
    this.gestisciPrenServ.deletePrenotazione(id).subscribe(
      rec => {
        this.prenotazioni = this.prenotazioni?.filter(prenotazione => prenotazione.id !== id);
  
        console.log("Delete avvenuta con successo")
      }
  
    )
  
  }
      


  }
