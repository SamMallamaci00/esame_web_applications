import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
email="campobaseb&b@gmail.com"
tel="3256954621"
partitaIva ="98765432109"
}
