import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AggiugniRecensioneComponent } from './aggiugni-recensione.component';

describe('AggiugniRecensioneComponent', () => {
  let component: AggiugniRecensioneComponent;
  let fixture: ComponentFixture<AggiugniRecensioneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AggiugniRecensioneComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AggiugniRecensioneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
