import { Component, OnInit } from '@angular/core';
import { Cliente } from '../../model/model';
import { ClientiServiceService } from '../../services/clienti-service/clienti-service.service';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { RecensioniServiceService } from '../../services/recensioni-service/recensioni-service.service';
import { error } from 'console';

@Component({
  selector: 'app-aggiugni-recensione',
  templateUrl: './aggiugni-recensione.component.html',
  styleUrl: './aggiugni-recensione.component.css'
})
export class AggiugniRecensioneComponent implements OnInit{

  autorizzato = false ;

  titolo: string = '';
  testo: string = '';
  valutazione: number = 0 ;
  id: number = 0;  // Esempio, questo potrebbe essere dinamico

  valid = false
  checked = false
  


  constructor(private clienteServ : ClientiServiceService, private authServ: AuthServiceService, private recenService: RecensioniServiceService){}


  ngOnInit(): void {
   this.clienteServ.getCliente(this.authServ.email).subscribe(
    rec => {
      if(rec){
        this.autorizzato = rec.autorizzato
        console.log("autorizzato: " + rec.autorizzato)
      }else{
        console.log("Errore nel caricamento")
      }
    }
   )
  }
 
  saveRecensione(id: number, titolo: string, testo:string, valutazione:number){
    this.isValid();

    if (this.valid){
    this.recenService.saveRecensione(id, this.authServ.email, titolo, testo, valutazione).subscribe(
      rec => {
        if (rec){
          console.log("Recensione inserita con successo")
        }else{
          console.log("Recensione non inserita")

        }
      }

    
    )}else{
      console.log("no")
    }
  }

  isValid(){
    if(this.titolo == '' || this.testo =="" || (this.valutazione == 0 || this.valutazione == null)){
      this.valid = false
      this.checked = true
    } else {
      this.valid = true
      this.checked = true
    }
      
  }
  
}
