import { Component } from '@angular/core';

@Component({
  selector: 'app-corousel',
  templateUrl: './corousel.component.html',
  styleUrl: './corousel.component.css'
})
export class CorouselComponent {

}
