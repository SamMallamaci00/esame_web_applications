/// <reference types="google.maps" />
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import H from '@here/maps-api-for-javascript';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {}

  display: any;
  
  // Centro della mappa (inizialmente Reggio Calabria)
  center: google.maps.LatLngLiteral = {
    lat: 38.147458,
    lng: 15.6577548
  };
  zoom = 15;

  // Posizione del marker
  markerPosition: google.maps.LatLngLiteral = {
    lat: 38.147458, // Posizione iniziale del marker (Reggio Calabria)
    lng: 15.6577548
  };
  markerTitle = 'Reggio Calabria'; // Titolo del marker

  // Aggiorna il centro della mappa al clic
  moveMap(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) {
      this.center = event.latLng.toJSON();
      this.markerPosition = this.center; // Sposta il marker sulla nuova posizione
    }
  }

  // Aggiorna le coordinate visualizzate mentre ci si muove sulla mappa
  move(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) {
      this.display = event.latLng.toJSON();
    }
  }
}

