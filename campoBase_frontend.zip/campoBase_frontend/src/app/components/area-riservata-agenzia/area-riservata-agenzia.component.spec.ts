import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AreaRiservataAgenziaComponent } from './area-riservata-agenzia.component';

describe('AreaRiservataAgenziaComponent', () => {
  let component: AreaRiservataAgenziaComponent;
  let fixture: ComponentFixture<AreaRiservataAgenziaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AreaRiservataAgenziaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AreaRiservataAgenziaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
