import { Component, OnInit } from '@angular/core';
import { AgenzieServiceService } from '../../services/agenzie-service/agenzie-service.service';
import { Agenzia, Pacchetto } from '../../model/model';
import { AuthServiceService } from '../../services/auth-service/auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-area-riservata-agenzia',
  templateUrl: './area-riservata-agenzia.component.html',
  styleUrl: './area-riservata-agenzia.component.css'
})
export class AreaRiservataAgenziaComponent implements OnInit{

  agenzia : Agenzia | undefined 
  pacchetti : Pacchetto[] | undefined


  constructor(private agenziaService : AgenzieServiceService, private authServ : AuthServiceService, private router : Router){}

  ngOnInit(): void {
    this.agenziaService.getAgenzia(this.authServ.email).subscribe(
      rec => {
        this.agenzia =  rec
      }
    )
  }



  leTueInfo(){
    this.router.navigate(['area-riservata-agenzia/le-tue-info',])

  }

  iTuoiPacchetti(){
    this.router.navigate(['area-riservata-agenzia/pacchetti',])
  }

  aggiungiPacchetto(){
    this.router.navigate(['area-riservata-agenzia/aggiungi-pacchetto',])
  }
}
