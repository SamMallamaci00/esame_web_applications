import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from '../app/components/home/home.component';
import { DatePickerComponent } from '../app/components/date-picker/date-picker.component';
import { FormsModule } from '@angular/forms';
import { CorouselComponent } from './components/corousel/corousel.component';
import { AreaRiservataClienteComponent } from './components/area-riservata-cliente/area-riservata-cliente.component';
import { AreaRiservataAdminComponent } from './components/area-riservata-admin/area-riservata-admin.component'; // Importa FormsModule
import { HttpClientModule } from '@angular/common/http';
import { PrenotaComponent } from './components/prenota/prenota.component';
import { PrenotazioniUtenteComponent } from './components/prenotazioni-utente/prenotazioni-utente.component';
import { CamereDispComponent } from './components/camere-disp/camere-disp.component';
import { CameraSingolaComponent } from './components/camera-singola/camera-singola.component';
import { CameraDoppiaComponent } from './components/camera-doppia/camera-doppia.component';
import { GestisciPrenotazioniComponent } from './components/gestisci-prenotazioni/gestisci-prenotazioni.component';
import { ClientiComponent } from './components/clienti/clienti.component';
import { AgenzieComponent } from './components/agenzie-elenco/agenzie.component';
import { AreaRiservataAgenziaComponent } from './components/area-riservata-agenzia/area-riservata-agenzia.component';
import { InfoAgenziaComponent } from './components/info-agenzia/info-agenzia.component';
import { AggiungiPacchettoComponent } from './components/aggiungi-pacchetto/aggiungi-pacchetto.component';
import { PacchettiAgenziaComponent } from './components/pacchetti-agenzia/pacchetti-agenzia.component';
import { AggiugniRecensioneComponent } from './components/aggiugni-recensione/aggiugni-recensione.component';
import { AgenzieViaggiComponent } from './components/agenzie-viaggi/agenzie-viaggi.component';
import { GoogleMapsModule } from '@angular/google-maps';
import { PacchettiAreaRiservataComponent } from './components/pacchetti-area-riservata/pacchetti-area-riservata.component';
import { RecensioniComponent } from './components/recensioni/recensioni.component';
import { PacchettiDispComponent } from './components/pacchetti-disp/pacchetti-disp.component';
import { LoginComponent } from './components/login/login.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { AggiungiAgenziaComponent } from './components/aggiungi-agenzia/aggiungi-agenzia.component';
import { RegistratiComponent } from './components/registrati/registrati.component';
import { FooterComponent } from './components/footer/footer.component';
import { PrezziComponent } from './components/prezzi/prezzi.component';








@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    DatePickerComponent,
    CorouselComponent,
    AreaRiservataClienteComponent,
    AreaRiservataAdminComponent,
    PrenotaComponent,
    PrenotazioniUtenteComponent,
    CamereDispComponent,
    CameraSingolaComponent,
    CameraDoppiaComponent,
    GestisciPrenotazioniComponent,
    ClientiComponent,
    AgenzieComponent,
    AreaRiservataAgenziaComponent,
    InfoAgenziaComponent,
    AggiungiPacchettoComponent,
    PacchettiAgenziaComponent,
    AggiugniRecensioneComponent,
    AgenzieViaggiComponent,
    PacchettiAreaRiservataComponent,
    RecensioniComponent,
    PacchettiDispComponent,
    LoginComponent,
    AggiungiAgenziaComponent,
    RegistratiComponent,
    FooterComponent,
    PrezziComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    GoogleMapsModule,
    NgxPaginationModule
    

  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
