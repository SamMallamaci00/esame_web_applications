import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AreaRiservataClienteComponent } from './components/area-riservata-cliente/area-riservata-cliente.component';
import { PrenotaComponent } from './components/prenota/prenota.component';
import { PrenotazioniUtenteComponent } from './components/prenotazioni-utente/prenotazioni-utente.component';
import { CamereDispComponent } from './components/camere-disp/camere-disp.component';
import { DatePickerComponent } from './components/date-picker/date-picker.component';
import { AreaRiservataAdminComponent } from './components/area-riservata-admin/area-riservata-admin.component';
import { GestisciPrenotazioniComponent } from './components/gestisci-prenotazioni/gestisci-prenotazioni.component';
import { ClientiComponent } from './components/clienti/clienti.component';
import { AgenzieComponent } from './components/agenzie-elenco/agenzie.component';
import { AreaRiservataAgenziaComponent } from './components/area-riservata-agenzia/area-riservata-agenzia.component';
import { InfoAgenziaComponent } from './components/info-agenzia/info-agenzia.component';
import { AggiungiPacchettoComponent } from './components/aggiungi-pacchetto/aggiungi-pacchetto.component';
import { AggiugniRecensioneComponent } from './components/aggiugni-recensione/aggiugni-recensione.component';
import { AgenzieViaggiComponent } from './components/agenzie-viaggi/agenzie-viaggi.component';
import { PacchettiAgenziaComponent } from './components/pacchetti-agenzia/pacchetti-agenzia.component';
import { PacchettiAreaRiservataComponent } from './components/pacchetti-area-riservata/pacchetti-area-riservata.component';
import { RecensioniComponent } from './components/recensioni/recensioni.component';
import { PacchettiDispComponent } from './components/pacchetti-disp/pacchetti-disp.component';
import { AggiungiAgenziaComponent } from './components/aggiungi-agenzia/aggiungi-agenzia.component';
import { PrezziComponent } from './components/prezzi/prezzi.component';

const routes: Routes = [
  {path : "" , component : HomeComponent},
  {path : "area-riservata-agenzia" , component : AreaRiservataAgenziaComponent,
    children: [
      {
        path: 'aggiungi-pacchetto', // Percorso del componente figlio
        component: AggiungiPacchettoComponent,
        
      },
      {
        path: 'le-tue-info', // Percorso del componente figlio
        component: InfoAgenziaComponent,
        
      },
      
      {
        path: 'pacchetti', // Percorso del componente figlio
        component: PacchettiAreaRiservataComponent,
        
      },
      {
        path: 'prenotazioni-utente', // Percorso del componente figlio
        component: PrenotazioniUtenteComponent,
      },
      
    ]
  },

  {path : "agenzie-viaggi" , component : AgenzieViaggiComponent,
    children: [
    {
      path: '', // Percorso del componente figlio
      component: DatePickerComponent,
     
    },]
  },

  {path : ":agenzia/pacchetti-turistici" , component : PacchettiAgenziaComponent,
   
  },
  {path: ':agenzia/pacchetti-turistici/:idpacchetto/prenota', // Percorso del componente figlio
        component: DatePickerComponent,
        children: [
          {
            path: ':checkindate/:checkoutdate/:guests/:rooms', // Percorso del componente figlio
            component: PacchettiDispComponent,
           
          },]
       
      
  },
 
  {path : "area-riservata-cliente" , component : AreaRiservataClienteComponent,
    children: [
      {
        path: 'prenota', // Percorso del componente figlio
        component: DatePickerComponent,
        children: [
          {
            path: 'camere-disp/:checkindate/:checkoutdate/:guests/:rooms', // Percorso del componente figlio
            component: CamereDispComponent,
          },],
      },
      {
        path: 'prenotazioni-utente', // Percorso del componente figlio
        component: PrenotazioniUtenteComponent,
      },
      {
        path: 'aggiungi-recensione', // Percorso del componente figlio
        component: AggiugniRecensioneComponent,
      },
      
    ]
  },
  {path : "area-riservaprenota" , component : PrenotaComponent},
  {path : "cosa-dicono-di-noi" , component : RecensioniComponent},

  {path : "prenota" , component : DatePickerComponent,
    children: [
      {
        path: 'camere-disp/:checkindate/:checkoutdate/:guests/:rooms', // Percorso del componente figlio
        component: CamereDispComponent,
      },],
  },

  {path : "area-riservata-admin" , component : AreaRiservataAdminComponent,
    children: [
      {path: ":id/pacchetti" , component : PacchettiAreaRiservataComponent},
      {path: 'agenzie', component : AgenzieComponent},
      {path: 'gestisci-prenotazioni/:nome/:cognome/:checkindate/:checkoutdate/:tipo', component : GestisciPrenotazioniComponent},
      {path: 'gestisci-prenotazioni', component : GestisciPrenotazioniComponent},
      {path: 'prenota', // Percorso del componente figlio
        component: DatePickerComponent,
        children: [
          {
            path: 'camere-disp/:checkindate/:checkoutdate/:guests/:rooms', // Percorso del componente figlio
            component: CamereDispComponent,
          },],
      },
      {path: 'prezzi', component : PrezziComponent},

      {path: 'clienti', component : ClientiComponent},
      {path: 'aggiungi-agenzia', component : AggiungiAgenziaComponent}


    ]
  }



];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
