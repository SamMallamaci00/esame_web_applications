import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from './services/auth-service/auth-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{

  constructor(private authServ : AuthServiceService){}

  title = 'bb_site';

    ngOnInit(): void {
     
    
  }
}
