package esameweb.bb_backend;

import esameweb.bb_backend.controller.ServiziRest;
import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.dao.ClienteDao;
import esameweb.bb_backend.persistenza.dao.PrenotazioneDao;
import esameweb.bb_backend.persistenza.dao.PrezzoDao;
import esameweb.bb_backend.persistenza.dao.UtenteDao;
import esameweb.bb_backend.persistenza.dao.postgress.AgenziaProxy;
import esameweb.bb_backend.persistenza.dao.postgress.PrenotazioneDaoPostgress;
import esameweb.bb_backend.persistenza.dao.postgress.PrezzoDaoPostgress;
import esameweb.bb_backend.persistenza.model.*;
import net.minidev.json.JSONUtil;
import org.checkerframework.checker.units.qual.C;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ServiceConfigurationError;
import java.util.logging.SimpleFormatter;

@SpringBootTest
class BbBackendApplicationTests {

    @Test
    public void getUtenti() {
        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        for (Utente u : uDao.findAll()) {
            System.out.println("------------");
            System.out.println("Nome: " + u.getNome());
            System.out.println("Cognome: " + u.getCognome());
            System.out.println("Email: " + u.getEmail());
            System.out.println("Password: " + u.getPassword());
            System.out.println("Ruolo: " + u.getRuolo());
        }
    }


    @Test
    public void getUtenteByEmail() {
        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        Utente u = uDao.findByPrimaryKey("samumalla@virgilio.it");
        System.out.println("------------");
        System.out.println("Nome: " + u.getNome());
        System.out.println("Cognome: " + u.getCognome());
        System.out.println("Email: " + u.getEmail());
        System.out.println("Password: " + u.getPassword());
        System.out.println("Ruolo: " + u.getRuolo());
    }

    @Test
    public void getPrenotazione() {
        PrenotazioneDao pDao = DBManager.getInstance().getPrenotazioneDao();
        Prenotazione p = pDao.findByPrimaryKey((long) 4);

        System.out.println(p.getPrezzoTot());
        System.out.println(p.getUtente().getEmail());

    }

    @Test
    public void getPrenotazioni() {
        PrenotazioneDao pDao = DBManager.getInstance().getPrenotazioneDao();



        List<Prenotazione> prenotazioni = pDao.findAll();


        for (Prenotazione p : prenotazioni) {
            System.out.println("-----------");
            System.out.println(p.getId());
            System.out.println(p.getPrezzoTot());
            System.out.println(p.getTipo());
        }

    }

    @Test
    public void getAgenzie(){
       List <Agenzia> agenzie = DBManager.getInstance().getAgenziaDao().findAll();
       for(Agenzia a : agenzie){
           System.out.println(a.getUtente().getNome());
           System.out.println(a.getInfo());
       }


    }


    @Test
    public void getClienti1() {
        List<Utente> clienti = DBManager.getInstance().getUtenteDao().findByRuoloLazy("cliente");

        for (Utente c : clienti) {
            System.out.println("-------");
            System.out.println(c.getNome());
            System.out.println(c.getCognome());
        }


    }

    @Test
    public void getAgenzia() {

        long l = 90L;
        System.out.println(DBManager.getInstance().getAgenziaDao().findByPrimaryKey(l).getUtente().getEmail());
    }

    @Test
    public void findPrezzo(){
        PrezzoDao pDo = DBManager.getInstance().getPrezzoDao();
        java.sql.Date dateInizio = Date.valueOf("2025-11-29");
        java.sql.Date dateFine = Date.valueOf("2025-11-30");

        System.out.println("costo1: " + pDo.findPrezzoByDates(dateInizio, dateFine, "singola").get(1));
 // prima quello senza sconto poi quello con lo sconto
    }


    @Test
    public void nuovaPrenotazione() {
        Prenotazione prenotazione = new Prenotazione();

        prenotazione.setId((long) 2);
        prenotazione.setUtente(DBManager.getInstance().getUtenteDao().findByPrimaryKey("samumalla@virgilio.it"));
        prenotazione.setPrezzoTot(1000);
        prenotazione.setCamera((long) 1);
        prenotazione.setData_inizio(new java.sql.Date(2024 - 1900, 8 - 1, 30));
        prenotazione.setData_fine(new java.sql.Date(2024 - 1900, 8 - 1, 30));
        prenotazione.setTipo("camera");

        System.out.println(prenotazione.getData_inizio());


        PrenotazioneDao pDao = DBManager.getInstance().getPrenotazioneDao();
        pDao.saveOrUpdate(prenotazione);
    }


    @Test
    public void nuouoUtenteDaFrontend() {
        Utente u = new Utente();
        u.setNome("Samuele");
        u.setCognome("Mallamaci");
        u.setEmail("samumalla@virgilio.it");
        u.setPassword("samu2000");
        u.setRuolo("cliente");
        DBManager.getInstance().getUtenteDao().saveOrUpdate(u);
    }


    @Test
    public void prova() {

        java.sql.Date sqlDate1 = java.sql.Date.valueOf("2024-07-04");
        java.sql.Date sqlDate2 = java.sql.Date.valueOf("2024-07-20");

        System.out.println(sqlDate1);
        System.out.println(sqlDate2);

        List<Integer> camereDsip = DBManager.getInstance().getPrenotazioneDao().findyRoomsDisp(sqlDate1,sqlDate2);

        System.out.println(camereDsip);




        String data1 = "2024-09-08";
        String data2 = "2024-09-15";



    }

    /*@Test
    public void modificaCliente(){
        Cliente c = new Cliente();
        Utente u = DBManager.getInstance().getUtenteDao().findByPrimaryKey("samumalla@virgilio.it");

        long longvalue = 0;
        c.setId(longvalue);

        c.setUtente(u);
        c.setAutorizzato(true);

        ClienteDao cDao = DBManager.getInstance().getClienteDao();
        cDao.update(c);

    }*/

    @Test
    public void getClientedyId(){
        ClienteDao cDao = DBManager.getInstance().getClienteDao();
        Cliente cliente = cDao.findById(35L);

        System.out.println(cliente.getId());
        System.out.println(cliente.getUtente().getEmail());
        System.out.println(cliente.getAutorizzato());


    }

    @Test
    public void getClienti(){
        ClienteDao cDao = DBManager.getInstance().getClienteDao();
        List<Cliente> clienti = cDao.findAll();

        for (Cliente c : clienti){
            System.out.println("id " + c.getId());
            System.out.println("utente" + c.getUtente().getEmail());
            System.out.println("autorizzato " + c.getAutorizzato());
        }

        System.out.println(clienti);
     }

     @Test
    public void proxyTest(){
        AgenziaProxy piattoProxy = new AgenziaProxy(DBManager.getInstance().getConnection(), 184);

        List<Pacchetto> pacchetti = piattoProxy.getPacchetti();

        for (Pacchetto p :pacchetti){
            System.out.println(p.getTitolo());
        }
     }
}
