package esameweb.bb_backend.controller.servlet;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.model.Utente;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/dammiClienti")
public class ClientiServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("dentro servlet");

        List<Utente> clienti = DBManager.getInstance().getUtenteDao().findByRuoloLazy("Cliente");


        req.setAttribute("lista_clienti", clienti);

        RequestDispatcher dispatcher = req.getRequestDispatcher("views/clienti.html");
        dispatcher.forward(req, resp);

    }



}
