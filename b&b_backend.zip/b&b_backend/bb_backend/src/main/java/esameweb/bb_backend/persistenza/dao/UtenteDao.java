package esameweb.bb_backend.persistenza.dao;


import esameweb.bb_backend.persistenza.model.Utente;

import java.util.List;

public interface UtenteDao {

    public List<Utente> findAll();

    public Utente findByPrimaryKey(String email);

    public void saveOrUpdate(Utente utente);

    public void delete(Utente utente);
    public List<Utente> findByRuoloLazy(String ruolo);



}
