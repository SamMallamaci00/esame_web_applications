package esameweb.bb_backend.persistenza.model;

public class Recensione {

    Long id;

    Utente utente;

    String titolo;

    String testo_rec;


    Short valutazione;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getTesto_rec() {
        return testo_rec;
    }

    public void setTesto_rec(String testo_rec) {
        this.testo_rec = testo_rec;
    }

    public Short getValutazione() {
        return valutazione;
    }

    public void setValutazione(Short valutazione) {
        this.valutazione = valutazione;
    }

}
