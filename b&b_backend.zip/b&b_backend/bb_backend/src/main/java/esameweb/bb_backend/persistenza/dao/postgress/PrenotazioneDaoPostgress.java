package esameweb.bb_backend.persistenza.dao.postgress;


import esameweb.bb_backend.persistenza.IdBroker;
import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.dao.PrenotazioneDao;
import esameweb.bb_backend.persistenza.model.Prenotazione;
import esameweb.bb_backend.persistenza.model.Utente;
import org.springframework.security.access.method.P;

import java.sql.*;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

public class PrenotazioneDaoPostgress implements PrenotazioneDao {

    Connection conn;

    public PrenotazioneDaoPostgress(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Prenotazione> findAll() {

        List<Prenotazione> prenotazioni = new ArrayList<Prenotazione>();

        String query = "select * from prenotazione";



        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);


            while (rs.next()){
                    Prenotazione prenotazione = new Prenotazione();
                    prenotazione.setId(rs.getLong("id"));
                    prenotazione.setPrezzoTot(rs.getFloat("prezzo_tot"));
                    prenotazione.setData_inizio(rs.getDate("data_inizio"));
                    prenotazione.setData_fine(rs.getDate("data_fine"));
                    prenotazione.setCamera(rs.getLong("camera"));
                    prenotazione.setTipo(rs.getString("tipo"));

                    Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));

                    prenotazione.setUtente(utente);

                    prenotazioni.add(prenotazione);
                }
            }

        catch (SQLException e) {
            e.printStackTrace();
        }

        return prenotazioni;
    }

    @Override
    public Prenotazione findByPrimaryKey(Long id) {
        Prenotazione prenotazione = new Prenotazione();
    String query = "select *"+
            " from prenotazione p where id = ? ";



                try {
                PreparedStatement st = conn.prepareStatement(query);
                st.setLong(1, id);

                ResultSet rs = st.executeQuery();


                if (rs.next()){
                    prenotazione.setId(rs.getLong("id"));
                    prenotazione.setPrezzoTot(rs.getFloat("prezzo_tot"));
                    prenotazione.setData_inizio(rs.getDate("data_inizio"));
                    prenotazione.setData_fine(rs.getDate("data_fine"));
                    prenotazione.setCamera(rs.getLong("camera"));
                    prenotazione.setTipo(rs.getString("tipo"));

                    Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));

                    prenotazione.setUtente(utente);

                }

                } catch (SQLException e) {
                e.printStackTrace();
                }

                return prenotazione;
    }

    @Override
    public void delete(Prenotazione prenotazione) {
        String query = " DELETE FROM prenotazione where id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, prenotazione.getId());
            st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    @Override
    public void saveOrUpdate(Prenotazione prenotazione) {
        if (prenotazione.getId() == null){


            String insertStr = "INSERT INTO prenotazione VAlUES (?, ?, ?, ?, ?, ?, ?)";

            try {
                PreparedStatement st = conn.prepareStatement(insertStr);

                Long  newId = IdBroker.getId(conn);
                prenotazione.setId(newId);

                st.setLong(1, newId);
                st.setString(2, prenotazione.getUtente().getEmail());
                st.setFloat(3, prenotazione.getPrezzoTot());
                st.setString(4, prenotazione.getTipo());
                st.setDate(5, prenotazione.getData_inizio());
                st.setDate(6, prenotazione.getData_fine());
                st.setLong(7, prenotazione.getCamera());
                st.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }

            }
        else {
            String updateStr = "UPDATE prenotazione set utente = ?, prezzo_tot = ?, tipo = ?, data_inizio = ?, data_fine = ?, camera = ? where id = ?";

            PreparedStatement st;

            try {
                st = conn.prepareStatement(updateStr);

                st.setString(1, prenotazione.getUtente().getEmail());
                st.setFloat(2, prenotazione.getPrezzoTot());
                st.setString(3, prenotazione.getTipo());
                st.setDate(4, prenotazione.getData_inizio());
                st.setDate(5, prenotazione.getData_fine());
                st.setLong(6, prenotazione.getCamera());
                st.setLong(7, prenotazione.getCamera());

                st.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

    }






    @Override
    public List<Prenotazione> findByUtenteLazy(Utente utente) {

        List<Prenotazione> prenotazioni = new ArrayList<>();

        System.out.println("prima della query");

        String query = "select * "+
                " from prenotazione p where p.utente = ? ";

        System.out.println("dopo della query\"");
        System.out.println(utente.getEmail());

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, utente.getEmail());
            ResultSet rs = st.executeQuery();

            while (rs.next()){

                Prenotazione prenotazione = new Prenotazione();
                prenotazione.setId(rs.getLong("id"));
                prenotazione.setPrezzoTot(rs.getFloat("prezzo_tot"));
                prenotazione.setData_inizio(rs.getDate("data_inizio"));
                prenotazione.setData_fine(rs.getDate("data_fine"));
                prenotazione.setCamera(rs.getLong("camera"));
                prenotazione.setTipo(rs.getString("tipo"));
                prenotazione.setUtente(utente);

                prenotazioni.add(prenotazione);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return prenotazioni;
    }



    @Override
    public Integer RoomsDispByDates(Date date1, Date date2) {

        Integer count = 0;

        List<Prenotazione> prenotazioni = new ArrayList<>();

        String query = " select COUNT(*) as numero_prenotazioni from Prenotazione p  where p.data_fine <= ?  and p.data_inizio >= ?";


        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setDate(2, java.sql.Date.valueOf(date1.toLocalDate()));
            st.setDate(1, java.sql.Date.valueOf(date2.toLocalDate()));
            ResultSet rs = st.executeQuery();

            if (rs.next()) {

                count = rs.getInt("numero_prenotazioni");
                /*Prenotazione prenotazione = new Prenotazione();
                prenotazione.setId(rs.getLong("id"));
                prenotazione.setPrezzoTot(rs.getFloat("prezzo_tot"));
                prenotazione.setData_inizio(rs.getDate("data_inizio"));
                prenotazione.setData_fine(rs.getDate("data_fine"));
                prenotazione.setCamera(rs.getLong("camera"));

                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));
                prenotazione.setUtente(utente);
                prenotazioni.add(prenotazione);

                System.out.println(rs.getLong("id"));
                System.out.println("DENTRO FINDBYDATES Data inizio: " + prenotazione.getData_inizio());*/



            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Prenotazioni trovate: " + count);
        return count;

    }

    @Override
    public List <Integer> findyRoomsDisp(Date date1, Date date2) {

        List<Integer> camereOccupate = new ArrayList<>();
        List<Integer> camereLibere = new ArrayList<>();
        Integer count = 0;

        String query = "SELECT p.camera as p_camera from prenotazione p where p.data_inizio >= DATE(?) and p.data_fine <= DATE(?) ";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setDate(1, java.sql.Date.valueOf(date1.toLocalDate()));
            st.setDate(2, java.sql.Date.valueOf(date2.toLocalDate()));
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                System.out.println("statement: "  + st);
                camereOccupate.add(rs.getInt("p_camera"));
                System.out.println(rs.getInt("p_camera"));

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        for(Integer i = 0; i<8; i++){
            if(!camereOccupate.contains(i)){
                camereLibere.add(i);
            }
        }
        System.out.println();
        return camereLibere;
    }



}
















/*Prenotazione prenotazione = null;
    String query = "select p.cod_prenotazione  as p_cod_prenotazione ,p.prezzo_tot as prezzo_tot,p.utente as p_utente,"
            +" u.nome as u_nome, u.email as u_email, u.cognome as u_cognome, u.password as u_password, u.ruolo as u_ruolo"
            +"from prenotazione p, utente u"
            +"where p.cod_prenotazione = ? and u.email = p.utente;";


        System.out.println("Arrivato dopo la query");




                try {
                PreparedStatement st = conn.prepareStatement(query);
                st.setInt(1, codPrenot);

                ResultSet rs = st.executeQuery();

                System.out.println("Dopo il ResultSet");

                if (rs.next()){
                prenotazione = new Prenotazione();
                prenotazione.setCodPrenot(rs.getInt("cod_prenotazione"));
                prenotazione.setPrezzoTot(rs.getFloat("prezzo_tot"));

                System.out.println("Dopo aver settato i valori della prenotazione");

                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));
                System.out.println("Dopo aver settato l'utente");
                prenotazione.setUtente(utente);

                }

                } catch (SQLException e) {
                e.printStackTrace();
                }*/
