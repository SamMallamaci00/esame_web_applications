package esameweb.bb_backend.persistenza.dao.postgress;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.IdBroker;
import esameweb.bb_backend.persistenza.dao.AgenziaDao;
import esameweb.bb_backend.persistenza.model.Agenzia;
import esameweb.bb_backend.persistenza.model.Pacchetto;
import esameweb.bb_backend.persistenza.model.Utente;

import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class AgenziaDaoPostgress implements AgenziaDao {


    Connection conn;

    public AgenziaDaoPostgress(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Agenzia> findAll() {
        List<Agenzia> agenzie = new ArrayList<Agenzia>();

        String query = "select * from agenzia";


        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);


            while (rs.next()){
                Agenzia agenzia = new Agenzia();
                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));
                agenzia.setId(rs.getLong("id"));
                agenzia.setUtente(utente);
                agenzia.setInfo(rs.getString("info"));
                agenzia.setLogo(rs.getString("logo"));


                String logoString = rs.getString("logo");



                agenzie.add(agenzia);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return agenzie;



    }

    @Override
    public Agenzia findByPrimaryKey(Long id) {

        Agenzia agenzia = new Agenzia();
        String query = "select * from agenzia where id =?";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();

            while (rs.next()){
                agenzia.setId(rs.getLong("id"));

                Utente u = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));
                agenzia.setUtente(u);

                agenzia.setInfo(rs.getString("info"));
                //agenzia.setLogo(rs.getBytes("logo"));
                System.out.println(rs.getBytes("logo"));

                return agenzia;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return agenzia;
    }

    @Override
    public String findPacchetto() {
        return null;
    }




    @Override
    public void update(Agenzia agenzia) {

        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();

        if (aDao.findByPrimaryKey(agenzia.getId())!= null){



                String updateStr = "UPDATE agenzia set info = ?, logo=? where id = ?";
                PreparedStatement st;


                try {
                    st = conn.prepareStatement(updateStr);

                    st.setString(1, agenzia.getInfo());
                    st.setString(2, agenzia.getLogo());

                    st.setLong(3, agenzia.getId());

                    st.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

    }



    @Override
    public Agenzia findByEmail(String email) {
        Agenzia agenzia = new Agenzia();
        String query = "select * from agenzia where utente =?";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, email);
            ResultSet rs = st.executeQuery();

            while (rs.next()){
                agenzia.setId(rs.getLong("id"));
                agenzia.setInfo(rs.getString("info") );
               agenzia.setLogo(rs.getString("logo"));
                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(email);
                agenzia.setUtente(utente);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return agenzia;
    }


    @Override
    public void delete(Agenzia agenzia) {
        String query = " DELETE FROM agenzia where id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, agenzia.getId());
            st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

}

