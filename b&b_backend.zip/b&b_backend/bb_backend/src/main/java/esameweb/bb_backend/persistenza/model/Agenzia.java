package esameweb.bb_backend.persistenza.model;

import java.util.List;

public class Agenzia {

    Long id;

    Utente utente;
    String info;

    String logo;

    List<Pacchetto> pacchetti;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public List<Pacchetto> getPacchetti() {
        return pacchetti;
    }

    public void setPacchetti(List<Pacchetto> pacchetti) {
        this.pacchetti = pacchetti;
    }
}
