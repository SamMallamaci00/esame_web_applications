package esameweb.bb_backend.controller;


import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.model.Utente;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.w3c.dom.ls.LSOutput;

import java.util.Base64;

@RestController
@CrossOrigin(value = "http://localhost:4200", allowCredentials = "true")
public class Auth {
    private class AuthToken {
        String token;
        Utente utente;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public Utente getUtente() {
            return utente;
        }

        public void setUtente(Utente utente) {
            this.utente = utente;
        }
    }


    @PostMapping("/login")
    public AuthToken login(@RequestBody Utente utente, HttpServletRequest req) throws Exception {
        String email = utente.getEmail();
        String rawPassword = utente.getPassword();

        // Instanzia l'encoder per comparare le password
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        // Cerca l'utente nel database usando l'email
        Utente utenteDB = DBManager.getInstance().getUtenteDao().findByPrimaryKey(email);
        if (utenteDB != null && passwordEncoder.matches(rawPassword, utenteDB.getPassword())) {
            // Genera un token semplice concatenando email e una stringa codificata
            String encodedToken = codificaBase64(email + ":" + utenteDB.getPassword());

            // Crea la sessione utente
            HttpSession session = req.getSession();
            session.setAttribute("user", utenteDB);

            // Crea l'oggetto AuthToken da restituire
            AuthToken auth = new AuthToken();
            auth.setToken(encodedToken);
            auth.setUtente(utenteDB);
            return auth;
        } else {
            // Caso in cui le credenziali sono errate
            System.out.println("Utente non trovato o password errata");
            throw new Exception("Invalid credentials");
        }
    }



    @PostMapping("/logout")
    public boolean logout(@RequestBody Utente utente, HttpServletRequest req) throws Exception{
        return true;
    }



    @PostMapping("/isAuthenticated")
    public boolean isAuthenticated(@RequestBody Utente utente, HttpServletRequest req) throws Exception{
        String auth = req.getHeader("Authorization");
        if (auth != null){
            String token = auth.substring("Basic".length());
            return getUserByToken(token) != null;
        }else {
            return false;
        }
    }

    public static Utente getUserByToken(String token) {
        if (token != null) {
            // Decodifica il token
            String decoded = decodificaBase64(token);
            String[] tokenParts = decoded.split(":");
            if (tokenParts.length != 2) {
                return null; // Token malformato
            }

            String email = tokenParts[0];
            String passwordHash = tokenParts[1];
            System.out.println("Dentro getUserByToken, email: " + email + " | password hash: " + passwordHash);

            // Trova l'utente dal database usando l'email
            Utente utenteDB = DBManager.getInstance().getUtenteDao().findByPrimaryKey(email);
            if (utenteDB != null && utenteDB.getPassword().equals(passwordHash)) {
                return utenteDB;
            } else {
                System.out.println("Utente non trovato o token non valido");
            }
        }
        return null;
    }


    private static String codificaBase64(String value){
        return Base64.getEncoder().encodeToString(value.getBytes());
    }

    private static String decodificaBase64(String value){
        return new String(Base64.getDecoder().decode(value.getBytes()));
    }
}

