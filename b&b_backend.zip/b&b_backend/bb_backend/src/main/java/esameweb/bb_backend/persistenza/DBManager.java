package esameweb.bb_backend.persistenza;

import esameweb.bb_backend.persistenza.dao.*;
import esameweb.bb_backend.persistenza.dao.postgress.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {

     private static DBManager instance = null;

    public static DBManager getInstance(){
        if (instance == null){
            instance = new DBManager();
        } return instance;
    }

    private DBManager(){
    }

    Connection conn = null;

    public Connection getConnection(){
        if (conn == null){
            try {
                conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/b&b", "postgres", "Samu2000");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }

    public PrenotazioneDao getPrenotazioneDao(){
        return new PrenotazioneDaoPostgress(getConnection());
    }

    public PrezzoDao getPrezzoDao(){
        return new PrezzoDaoPostgress(getConnection());
    }



    public UtenteDao getUtenteDao(){
        return new UtenteDaoPostgress(getConnection());
    }

    public ClienteDao getClienteDao() {return new ClienteDaoPostgress(getConnection());
    }

    public AgenziaDao getAgenziaDao() {return new AgenziaDaoPostgress(getConnection());}

    public PacchettoDao getPacchettoDao(){return new PacchettoDaoPostgress(getConnection());}

    public RecensioneDao getRecensioneDao(){return new RecensioneDaoPostgress(getConnection());}
}
