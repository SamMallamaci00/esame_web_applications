package esameweb.bb_backend;



import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ServletUtil {

    @RequestMapping("/views/**")
    public String templateHandler(HttpServletRequest request) {
        String resource = request.getRequestURI().substring("/views/".length());
        if (resource.endsWith(".html")) {
            resource = resource.substring(0, resource.indexOf(".html"));
        }
        return resource;  // Restituisce il nome del template senza estensione
    }
}
