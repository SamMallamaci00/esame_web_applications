package esameweb.bb_backend.persistenza.dao.postgress;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.model.Agenzia;
import esameweb.bb_backend.persistenza.model.Pacchetto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgenziaProxy extends Agenzia {

    Connection conn;

    public AgenziaProxy(Connection conn, long id) {
        setPacchetti(null);
        setId(id);
        this.conn = conn;
    }
    @Override
    public List<Pacchetto> getPacchetti() {

        if(super.getPacchetti() == null) {

            List<Pacchetto> pacchetti = new ArrayList<>();


            String query = "select  p.id as p_id, p.prezzo as p_prezzo, p.descrizione as p_descrizione, p.immagine as p_immagine " +
                    ", p.titolo as p_titolo , p.agenzia as p_agenzia" +
                    "  from pacchetto p, agenzia a where a.utente = p.agenzia and a.id = ? ";


            try {
                PreparedStatement st = conn.prepareStatement(query);
                st.setLong(1, getId());
                ResultSet rs = st.executeQuery();

                while (rs.next()) {

                    Pacchetto pacchetto = new Pacchetto();
                    pacchetto.setId(rs.getLong("p_id"));
                    pacchetto.setPrezzo(rs.getFloat("p_prezzo"));
                    pacchetto.setDescrizione(rs.getString("p_descrizione"));
                    pacchetto.setImmagine(rs.getString("p_immagine"));
                    pacchetto.setTitolo(rs.getString("p_titolo"));



                    Agenzia a = DBManager.getInstance().getAgenziaDao().findByEmail(rs.getString("p_agenzia"));
                    pacchetto.setAgenzia(a);

                    pacchetti.add(pacchetto);
                }
                super.setPacchetti(pacchetti);


            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return super.getPacchetti();
    }

}

