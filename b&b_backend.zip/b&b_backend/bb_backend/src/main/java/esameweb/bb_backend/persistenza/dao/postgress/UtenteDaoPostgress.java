package esameweb.bb_backend.persistenza.dao.postgress;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.dao.UtenteDao;
import esameweb.bb_backend.persistenza.model.Prenotazione;
import esameweb.bb_backend.persistenza.model.Utente;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.awt.geom.RectangularShape;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtenteDaoPostgress implements UtenteDao {
    Connection conn;
    public UtenteDaoPostgress(Connection conn) {
        this.conn = conn;
    }


    @Override
    public List<Utente> findAll() {
        List<Utente> utenti = new ArrayList<Utente>();
        String query = "select * from utente";

        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()){
                Utente utente = new Utente();
                utente.setEmail(rs.getString("email"));
                utente.setCognome(rs.getString("cognome") );
                utente.setNome(rs.getString("nome"));
                utente.setPassword(rs.getString("password"));
                utente.setRuolo(rs.getString("ruolo"));

                utenti.add(utente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utenti;
    }

    @Override
    public Utente findByPrimaryKey(String email) {
       Utente utente = null;
        String query = "select * from utente where email = ?";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1,email);
            ResultSet rs = st.executeQuery();

            if (rs.next()){
                utente = new Utente();
                utente.setEmail(rs.getString("email"));
                utente.setCognome(rs.getString("cognome") );
                utente.setNome(rs.getString("nome"));
                utente.setPassword(rs.getString("password"));
                utente.setRuolo(rs.getString("ruolo"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utente;
    }

    @Override
    public void saveOrUpdate(Utente utente) {
        UtenteDao uDao = DBManager.getInstance().getUtenteDao();

         if(uDao.findByPrimaryKey(utente.getEmail()) == null){
             String insertStr = "INSERT INTO utente VALUES (?, ?, ?, ?, ?); ";

             try {
                 PreparedStatement st = conn.prepareStatement(insertStr);

                 BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

                 // Cifrare la password dell'utente
                 String encodedPassword = passwordEncoder.encode(utente.getPassword());
                 System.out.println("Password hash: " + encodedPassword);

                 System.out.println("Nome: " + utente.getNome() + " Cognome: " + utente.getCognome() + " Email: " + utente.getEmail());
                 st.setString(1, utente.getEmail());
                 st.setString(2, encodedPassword);
                 st.setString(3, utente.getNome());
                 st.setString(4, utente.getCognome());
                 st.setString(5, utente.getRuolo());

                 st.executeUpdate();

                 if(utente.getRuolo().equals("agenzia")){

                 }
             } catch (SQLException e) {
                 e.printStackTrace();
             }

         } else {
             String updateStr = "UPDATE utente set password = ?, nome = ?, cognome = ?, ruolo = ? where email = ?";

             try {
                 BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

                 // Cifrare la password dell'utente
                 String encodedPassword = passwordEncoder.encode(utente.getPassword());
                 System.out.println("Password hash: " + encodedPassword);
                 PreparedStatement st = conn.prepareStatement(updateStr);

                 st.setString(1, encodedPassword);
                 st.setString(2, utente.getNome());
                 st.setString(3, utente.getCognome());
                 st.setString(4, utente.getRuolo());
                 st.setString(5, utente.getEmail());

                 st.executeUpdate();

             } catch (SQLException e) {
                 e.printStackTrace();
             }
         }

    }

    @Override
    public void delete(Utente utente) {
        String query = " DELETE FROM utente where email = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, utente.getEmail());
            st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public List<Utente> findByRuoloLazy(String ruolo) {
        List<Utente> utenti = new ArrayList<Utente>();
        String query = "select * from utente where ruolo =?";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, ruolo);
            ResultSet rs = st.executeQuery();

            while (rs.next()){
                Utente utente = new Utente();
                utente.setEmail(rs.getString("email"));
                utente.setCognome(rs.getString("cognome") );
                utente.setNome(rs.getString("nome"));
                utente.setPassword(rs.getString("password"));
                utente.setRuolo(rs.getString("ruolo"));

                utenti.add(utente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utenti;
    }

}
