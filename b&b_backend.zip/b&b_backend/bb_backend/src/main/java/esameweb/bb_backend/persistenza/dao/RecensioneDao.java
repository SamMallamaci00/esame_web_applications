package esameweb.bb_backend.persistenza.dao;

import esameweb.bb_backend.persistenza.model.Recensione;

import java.util.List;

public interface RecensioneDao {


    public void addRecensione(Recensione recensione);

    public List<Recensione> findAll();

}
