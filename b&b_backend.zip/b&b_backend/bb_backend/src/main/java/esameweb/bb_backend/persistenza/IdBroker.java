package esameweb.bb_backend.persistenza;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class IdBroker {
    private static final String query = "SELECT nextval ('db_sequence') AS id";

    public static Long getId(Connection conn){
        Long id = null;

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            resultSet.next();

            id = resultSet.getLong("id");


        } catch (SQLException e) {
            e.printStackTrace();
        }


    return id;

    }

}
