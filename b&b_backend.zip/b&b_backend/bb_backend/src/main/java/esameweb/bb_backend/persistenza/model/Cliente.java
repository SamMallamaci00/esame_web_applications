package esameweb.bb_backend.persistenza.model;

public class Cliente {

    Long id;

    Utente utente;

    Boolean autorizzato;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public Boolean getAutorizzato() {
        return autorizzato;
    }

    public void setAutorizzato(Boolean autorizzato) {
        this.autorizzato = autorizzato;
    }
}
