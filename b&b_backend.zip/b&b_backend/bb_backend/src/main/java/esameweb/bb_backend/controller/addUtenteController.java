package esameweb.bb_backend.controller;


import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.dao.ClienteDao;
import esameweb.bb_backend.persistenza.dao.UtenteDao;
import esameweb.bb_backend.persistenza.model.Cliente;
import esameweb.bb_backend.persistenza.model.Utente;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class addUtenteController {
    @PostMapping("addUtente")
    public ResponseEntity<String> addUtente(@RequestBody List<Utente> utenti){




        for (Utente u : utenti) {
           UtenteDao uDao = DBManager.getInstance().getUtenteDao();



           uDao.saveOrUpdate(u);
       }





        return ResponseEntity.status(HttpStatus.CREATED).body("OK");

    }



}
