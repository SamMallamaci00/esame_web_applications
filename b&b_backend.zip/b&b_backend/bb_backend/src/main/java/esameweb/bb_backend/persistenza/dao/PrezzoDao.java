package esameweb.bb_backend.persistenza.dao;

import esameweb.bb_backend.persistenza.model.Prenotazione;
import esameweb.bb_backend.persistenza.model.Prezzo;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public interface PrezzoDao {

    public List<Prezzo> findAll();

    public Prezzo findByPrimaryKey(String servizio);

    public void saveOrUpdate(Prezzo prezzo);

    public void delete(Prezzo prezzo);

    public ArrayList<BigDecimal> findPrezzoByDates(java.sql.Date dateInizio, java.sql.Date dateFine, String tipoCamera) ;
}
