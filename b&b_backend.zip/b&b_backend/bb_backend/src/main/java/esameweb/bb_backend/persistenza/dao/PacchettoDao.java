package esameweb.bb_backend.persistenza.dao;

import esameweb.bb_backend.persistenza.model.Agenzia;
import esameweb.bb_backend.persistenza.model.Pacchetto;

import java.math.BigDecimal;
import java.util.List;

public interface PacchettoDao {

    public List<Pacchetto> findByAgenzia(String agenzia);

    public List<Pacchetto> findById(Long id);


    public Pacchetto findByPrimaryKey(Long id);


    public void saveOrUpdatePacchetto(Pacchetto pacchetto);

    public BigDecimal getPrezzo(long id);

    public void delete(Pacchetto pacchetto);

}
