package esameweb.bb_backend.persistenza.dao.postgress;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.dao.AgenziaDao;
import esameweb.bb_backend.persistenza.dao.ClienteDao;
import esameweb.bb_backend.persistenza.model.Agenzia;
import esameweb.bb_backend.persistenza.model.Cliente;
import esameweb.bb_backend.persistenza.model.Utente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDaoPostgress implements ClienteDao {


    Connection conn;

    public ClienteDaoPostgress(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Cliente> findAll() {
        List<Cliente> clienti = new ArrayList<Cliente>();

        String query = "select * from cliente";


        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);


            while (rs.next()){
                Cliente cliente = new Cliente();
                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));
                cliente.setId(rs.getLong("id"));
                cliente.setUtente(utente);
                cliente.setAutorizzato(rs.getBoolean("autorizzato"));


                clienti.add(cliente);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return clienti;
    }

    @Override
    public Cliente findById(Long id){

        Cliente c = new Cliente();
        String query = "select * from cliente where id =?";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();

            while (rs.next()){
                c.setId(rs.getLong("id"));
                c.setAutorizzato(rs.getBoolean("autorizzato") );

                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("utente"));

                c.setUtente(utente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return c ;

    }

    @Override
    public Cliente findByEmail(String email) {
            Cliente cliente = new Cliente();
            String query = "select * from cliente c where c.utente =?";

            try {
                PreparedStatement st = conn.prepareStatement(query);
                st.setString(1, email);
                ResultSet rs = st.executeQuery();

                while (rs.next()){
                    cliente.setId(rs.getLong("id"));
                    cliente.setAutorizzato(rs.getBoolean("autorizzato") );

                    Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(email);
                    cliente.setUtente(utente);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return cliente;
        }



    @Override
    public void delete(Cliente cliente) {
        String query = " DELETE FROM cliente where id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, cliente.getId());
            st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void update(Cliente c) {
         {

            ClienteDao cDao = DBManager.getInstance().getClienteDao();

            if (cDao.findById(c.getId())!= null){



                String updateStr = "UPDATE cliente set utente = ?, autorizzato =? where id = ?";
                PreparedStatement st;


                try {
                    st = conn.prepareStatement(updateStr);

                    st.setString(1, c.getUtente().getEmail());
                    st.setBoolean(2, c.getAutorizzato());

                    st.setLong(3, c.getId());

                    st.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

        }
    }
}

