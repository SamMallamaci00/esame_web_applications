package esameweb.bb_backend.persistenza.dao;

import esameweb.bb_backend.persistenza.model.Agenzia;

import java.util.List;

public interface AgenziaDao {

    public List<Agenzia> findAll();

    public Agenzia findByPrimaryKey(Long id);

    public Agenzia findByEmail(String email);

    public String findPacchetto();

    public void update(Agenzia agenzia);

    public void delete(Agenzia agenzia);







}
