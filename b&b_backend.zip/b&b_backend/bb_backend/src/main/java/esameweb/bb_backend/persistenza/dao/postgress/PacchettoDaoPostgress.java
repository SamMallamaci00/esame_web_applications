package esameweb.bb_backend.persistenza.dao.postgress;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.IdBroker;
import esameweb.bb_backend.persistenza.dao.PacchettoDao;
import esameweb.bb_backend.persistenza.model.Agenzia;
import esameweb.bb_backend.persistenza.model.Pacchetto;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacchettoDaoPostgress implements PacchettoDao {

    Connection conn;

    public PacchettoDaoPostgress(Connection conn) {
        this.conn = conn;
    }


    @Override
    public Pacchetto findByPrimaryKey(Long id) {

     Pacchetto pacchetto = new Pacchetto();



    String query = "select *  from pacchetto p where p.id = ? ";


        try {
        PreparedStatement st = conn.prepareStatement(query);
        st.setLong(1, id);
        ResultSet rs = st.executeQuery();

        if (rs.next()){
            pacchetto.setId(rs.getLong("id"));
            pacchetto.setPrezzo(rs.getFloat("prezzo"));
            pacchetto.setDescrizione(rs.getString("descrizione"));
            pacchetto.setImmagine(rs.getString("immagine"));
            pacchetto.setTitolo(rs.getString("titolo"));

            Agenzia a = DBManager.getInstance().getAgenziaDao().findByEmail(rs.getString("agenzia"));
            pacchetto.setAgenzia(a);
            return pacchetto;
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
        return null;
}


    @Override
    public List<Pacchetto> findByAgenzia(String agenzia) {
        List<Pacchetto> pacchetti = new ArrayList<>();


        String query = "select *  from pacchetto p where p.agenzia = ? ";


        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, agenzia);
            ResultSet rs = st.executeQuery();

            while (rs.next()){

                Pacchetto pacchetto = new Pacchetto();
                pacchetto.setId(rs.getLong("id"));
                pacchetto.setPrezzo(rs.getFloat("prezzo"));
                pacchetto.setDescrizione(rs.getString("descrizione"));
                pacchetto.setImmagine(rs.getString("immagine"));
                pacchetto.setTitolo(rs.getString("titolo"));




                Agenzia a = DBManager.getInstance().getAgenziaDao().findByEmail(agenzia);
                pacchetto.setAgenzia(a);

                pacchetti.add(pacchetto);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pacchetti;
    }

    @Override
    public List<Pacchetto> findById(Long id) {
        List<Pacchetto> pacchetti = new ArrayList<>();


        String query = "select *  from pacchetto p where p.id = ? ";


        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();

            while (rs.next()){

                Pacchetto pacchetto = new Pacchetto();
                pacchetto.setId(rs.getLong("id"));
                pacchetto.setPrezzo(rs.getFloat("prezzo"));
                pacchetto.setDescrizione(rs.getString("descrizione"));
                pacchetto.setImmagine(rs.getString("immagine"));
                pacchetto.setTitolo(rs.getString("titolo"));



            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pacchetti;
    }



    @Override
    public void saveOrUpdatePacchetto(Pacchetto pacchetto){
        PacchettoDao pDao = DBManager.getInstance().getPacchettoDao();
        pDao.findByPrimaryKey(pacchetto.getId());

        if(pDao.findByPrimaryKey(pacchetto.getId()) == null){
            String insertStr = "INSERT INTO pacchetto VALUES (?, ?, ?, ?,?,?); ";

            try {
                PreparedStatement st = conn.prepareStatement(insertStr);

                Long id = IdBroker.getId(conn);
                st.setLong(1, id);
                st.setString(2, pacchetto.getAgenzia().getUtente().getEmail());
                st.setFloat(3, pacchetto.getPrezzo());
                st.setString(4, pacchetto.getDescrizione());
                st.setString(5, pacchetto.getImmagine());
                st.setString(6, pacchetto.getTitolo());


                st.executeUpdate();


            } catch (SQLException e) {
                e.printStackTrace();
            }

        } else {
            String updateStr = "UPDATE pacchetto set agenzia = ?, prezzo = ?, descrizione = ?, immagine = ?, titolo = ?  where id = ?";
            try {
                PreparedStatement st = conn.prepareStatement(updateStr);
                st.setString(1, pacchetto.getAgenzia().getUtente().getEmail());
                st.setFloat(2, pacchetto.getPrezzo());
                st.setString(3, pacchetto.getDescrizione());
                st.setString(4, pacchetto.getImmagine());
                st.setString(5, pacchetto.getTitolo());

                st.setLong(6, pacchetto.getId());



                st.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public BigDecimal getPrezzo(long id) {
        String query = "select *  from pacchetto p where p.id = ? ";


        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();

            while (rs.next()){
                return rs.getBigDecimal("prezzo");

            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void delete(Pacchetto pacchetto) {
        String query = " DELETE FROM pacchetto where id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1, pacchetto.getId());
            st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


}
