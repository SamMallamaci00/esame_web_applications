package esameweb.bb_backend.persistenza.model;

import java.math.BigDecimal;

public class Prezzo {
    String Servizio;
    BigDecimal Costo;

    BigDecimal sconto;

    public String getServizio() {
        return Servizio;
    }

    public void setServizio(String servizio) {
        Servizio = servizio;
    }

    public BigDecimal getCosto() {
        return Costo;
    }

    public void setCosto(BigDecimal costo) {
        Costo = costo;
    }

    public BigDecimal getSconto() {
        return sconto;
    }

    public void setSconto(BigDecimal sconto) {
        this.sconto = sconto;
    }
}





