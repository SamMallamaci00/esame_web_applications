package esameweb.bb_backend.persistenza.dao.postgress;

import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.IdBroker;
import esameweb.bb_backend.persistenza.dao.RecensioneDao;
import esameweb.bb_backend.persistenza.model.Prenotazione;
import esameweb.bb_backend.persistenza.model.Recensione;
import esameweb.bb_backend.persistenza.model.Utente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecensioneDaoPostgress implements RecensioneDao {

    Connection conn;

    public RecensioneDaoPostgress(Connection conn) {
        this.conn = conn;
    }
    @Override
    public void addRecensione(Recensione recensione) {

        if (recensione.getId() == 0L){


            String insertStr = "INSERT INTO recensione VAlUES (?, ?, ?, ?, ?)";

            try {
                PreparedStatement st = conn.prepareStatement(insertStr);

                Long  newId = IdBroker.getId(conn);
                recensione.setId(newId);

                st.setLong(1, newId);
                st.setString(2, recensione.getUtente().getEmail());
                st.setString(3, recensione.getTitolo());
                st.setString(4, recensione.getTesto_rec());
                st.setShort(5, recensione.getValutazione());
                st.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
        else {
            String updateStr = "UPDATE recensione set scritta_da = ?, titolo = ?, testo_rec = ?, valutazione = ? where id = ?";

            PreparedStatement st;

            try {
                st = conn.prepareStatement(updateStr);


                st.setString(1, recensione.getUtente().getEmail());
                st.setString(2, recensione.getTitolo());
                st.setString(3, recensione.getTesto_rec());
                st.setShort(4, recensione.getValutazione());
                st.setLong(5, recensione.getId());

                st.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }


    }

    @Override
    public List<Recensione> findAll() {
        List<Recensione> recensioni = new ArrayList<Recensione>();

        String query = "select * from recensione";


                /*"select p.cod as p_cod_prenotazione, p.prezzo as p_prezzo_tot, p.utente as p_utente"
                +"u.email as u_email, u.nome as u_nome, u.cognome as u_cognome, u.ruolo as u_ruolo"
                +"s.cod as s_cod_prenotazione"
                +"from prenotazione p, utente u, stanza_occupata s"
                +"where p.cod = s.cod and ";*/

        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);


            while (rs.next()){
                Recensione recensione = new Recensione();
                recensione.setId(rs.getLong("id"));
                recensione.setValutazione(rs.getShort("valutazione"));
                recensione.setTitolo(rs.getString("titolo"));
                recensione.setTesto_rec(rs.getString("testo_rec"));


                Utente utente = DBManager.getInstance().getUtenteDao().findByPrimaryKey(rs.getString("scritta_da"));

                recensione.setUtente(utente);

                recensioni.add(recensione);
            }
        }

        catch (SQLException e) {
            e.printStackTrace();
        }

        return recensioni;
    }
}
