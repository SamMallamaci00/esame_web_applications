package esameweb.bb_backend.persistenza.dao;

import esameweb.bb_backend.persistenza.model.Camera;
import esameweb.bb_backend.persistenza.model.Prenotazione;
import esameweb.bb_backend.persistenza.model.Utente;


import java.sql.Date;
import java.util.List;

public interface PrenotazioneDao {

    public List<Prenotazione> findAll();

    public Prenotazione findByPrimaryKey(Long id);

    public void delete(Prenotazione prenotazione);

    public void saveOrUpdate(Prenotazione prenotazione);

    public List<Prenotazione> findByUtenteLazy(Utente utente);



    public Integer RoomsDispByDates(Date date1, Date date2);

    public List<Integer> findyRoomsDisp(Date date1, Date date2);
}
