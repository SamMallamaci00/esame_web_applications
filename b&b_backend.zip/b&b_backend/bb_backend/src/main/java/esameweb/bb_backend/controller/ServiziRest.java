package esameweb.bb_backend.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import esameweb.bb_backend.persistenza.DBManager;
import esameweb.bb_backend.persistenza.dao.*;
import esameweb.bb_backend.persistenza.dao.postgress.AgenziaProxy;
import esameweb.bb_backend.persistenza.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.multipart.MultipartFile;


import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/", allowCredentials = "true")
public class ServiziRest {




    @GetMapping("getAllPrenotazioni")
    public List<Prenotazione> getAllPrenotazioni(){
        System.out.println("dentro getPrenotazioni");
        List<Prenotazione> p = DBManager.getInstance().getPrenotazioneDao().findAll();
        return p;

    }


    @GetMapping("getPrenotazioni")
    public List<Prenotazione> getPrenotazioni(@RequestParam("date1") String date1, @RequestParam("date2") String date2,
                                                @RequestParam("utente") String utente, @RequestParam("ruolo") String ruolo){

        List<Prenotazione> prenotazioniReturn = new ArrayList<>();
        List<Prenotazione> prenotazioniRicerca = new ArrayList<>();

        prenotazioniRicerca= DBManager.getInstance().getPrenotazioneDao().findAll();




        return prenotazioniReturn;
    }




    @GetMapping("dammiUtenti")
    public List<Utente> getUtenti(){
        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        List<Utente> utenti = uDao.findAll();
        return utenti;
    }



    @GetMapping("getClienti")
    public List<Cliente> getCliente(){
       ClienteDao cDao = DBManager.getInstance().getClienteDao();
       List<Cliente> clienti = cDao.findAll();
        return clienti;
    }

    @PostMapping("nuovoUtente")
    public ResponseEntity<String> addUtente(@RequestParam String nome, @RequestParam String cognome,
                                            @RequestParam String email, @RequestParam String password,
                                            @RequestParam String ruolo){

        //BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        Utente utente = new Utente();

        utente.setNome(nome);
        utente.setCognome(cognome);
        utente.setEmail(email);
        utente.setRuolo(ruolo);

        //String hashedPassword = passwordEncoder.encode(utente.getPassword());
        utente.setPassword(password);


        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        uDao.saveOrUpdate(utente);





        return ResponseEntity.status(HttpStatus.CREATED).body("Utente aggiunto con  creata con successo!");

    }




    @GetMapping("getPrezzoCamera")
    public ArrayList<BigDecimal> getPrezzo(@RequestParam("date1") String date1, @RequestParam("date2") String date2,@RequestParam("servizio") String servizio){
        try {
            java.sql.Date sqlDate1 = java.sql.Date.valueOf(date1);
            java.sql.Date sqlDate2 = java.sql.Date.valueOf(date2);


            System.out.println(sqlDate1);
            System.out.println(sqlDate2);

            PrezzoDao pDAo = DBManager.getInstance().getPrezzoDao();



            return  pDAo.findPrezzoByDates(sqlDate1, sqlDate2, servizio);
        }
        catch (HttpClientErrorException.NotFound ex) {
            System.err.println("Risorsa non trovata: " + ex.getMessage());
            return null;// Nessuna camera disponibile in caso di errore 404
        }
    }



    @GetMapping("cercaDisponibilita")
    public Integer carcaDiponibilita(@RequestParam("date1") String date1, @RequestParam("date2") String date2,
                                     @RequestParam("guests") int guests, @RequestParam("rooms") int rooms){
        try {
            java.sql.Date sqlDate1 = java.sql.Date.valueOf(date1);
            java.sql.Date sqlDate2 = java.sql.Date.valueOf(date2);


            System.out.println(sqlDate1);
            System.out.println(sqlDate2);

            PrenotazioneDao pDAo = DBManager.getInstance().getPrenotazioneDao();
           List<Integer> camereOccupate = pDAo.findyRoomsDisp(sqlDate1, sqlDate2);



            return 8 ;
        }
        catch (HttpClientErrorException.NotFound ex) {
            System.err.println("Risorsa non trovata: " + ex.getMessage());
            return 0;// Nessuna camera disponibile in caso di errore 404
        }

    }



    @GetMapping("getInfo")
    public String getInfo(@RequestParam("agenzia") String email){
        Agenzia agenzia = new Agenzia();
        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();


        return aDao.findByEmail(email).getInfo();
    }

    @GetMapping("getAgenzie")
    public List<Agenzia> getAgenzie(){
        List<Agenzia> agenzie = new ArrayList<>();
        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();

        agenzie = aDao.findAll();
        return agenzie;
    }

    @GetMapping("getAgenzia")
    public Agenzia getAgenzia(@RequestParam("agenzia") String email){

        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();

        Agenzia agenzia = aDao.findByEmail(email);
        return agenzia;
    }

    @GetMapping("getAgenziaWithId")
    public Agenzia getAgenzia(@RequestParam("id") long id){

        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();

        Agenzia agenzia = aDao.findByPrimaryKey(id);
        return agenzia;
    }


    @GetMapping("getPacchettiAgenzia")
    public List<Pacchetto> getAgenzie(@RequestParam("agenzia") String email){
        List<Pacchetto> pacchetti = new ArrayList<>();
        PacchettoDao pDao = DBManager.getInstance().getPacchettoDao();
        pacchetti = pDao.findByAgenzia(email);





        return pacchetti;
    }

    @GetMapping("getPacchetto")
    public Pacchetto getPacchetto(@RequestParam("id") Long id){
        return DBManager.getInstance().getPacchettoDao().findByPrimaryKey(id);
    }

    @GetMapping("getPrezzoPacchetto")
    public BigDecimal getPacchetto(@RequestParam("id") long id){
        return DBManager.getInstance().getPacchettoDao().getPrezzo(id);
    }


    @GetMapping("getPacchettiId")
    public List<Pacchetto> getPacchettoId(@RequestParam("id") Long id) {
        List<Pacchetto> pacchetti = new ArrayList<>();
        PacchettoDao pDao = DBManager.getInstance().getPacchettoDao();

        Agenzia a = DBManager.getInstance().getAgenziaDao().findByPrimaryKey(id);

        pacchetti = pDao.findByAgenzia(a.getUtente().getEmail());


        return pacchetti;
    }





    @PostMapping("updateAgenzia")
    public ResponseEntity<String> updateAgenzia(@RequestParam("id") Integer id, @RequestParam("utente") String email,
                                                @RequestParam("info") String info, @RequestPart("logo") String logo){

        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();

        Agenzia agenzia = new Agenzia();

        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        Utente utente = uDao.findByPrimaryKey(email);

        agenzia.setUtente(utente);
        agenzia.setInfo(info);
        agenzia.setId(id.longValue());
         agenzia.setLogo(logo);  // Ottieni i byte del file immagine



        aDao.update(agenzia);

        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");
    }


    @PostMapping("addPrenotazione")
    public ResponseEntity<String> addPrenotazione(@RequestParam("date1") String date1, @RequestParam("date2") String date2,
                                                  @RequestParam("utente") String utente, @RequestParam("room") int room,
                                                  @RequestParam("prezzo")float prezzo, @RequestParam("tipo") String tipo) {
        {


            java.sql.Date sqlDate1 = java.sql.Date.valueOf(date1);
            java.sql.Date sqlDate2 = java.sql.Date.valueOf(date2);
            Utente u = DBManager.getInstance().getUtenteDao().findByPrimaryKey(utente);

            long longvalue = room;
            Prenotazione p = new Prenotazione();
            p.setId(null);
            p.setTipo(tipo);
            p.setUtente(u);
            p.setData_inizio(sqlDate1);
            p.setData_fine(sqlDate2);
            p.setCamera(longvalue);
            p.setPrezzoTot(prezzo);
            PrenotazioneDao pDAo = DBManager.getInstance().getPrenotazioneDao();
            pDAo.saveOrUpdate(p);



            return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

        }
    }

    @PostMapping("addPacchetto")
    public ResponseEntity<String> addPacchetto(@RequestParam("id") Integer id,
                                               @RequestParam("agenzia") String email,
                                               @RequestParam("prezzo") float prezzo,
                                               @RequestParam("descrizione") String descrizione,
                                               @RequestPart("immagine") String immagineFile,
                                               @RequestPart("titolo") String titolo) {  // Cambia qui a MultipartFile


        PacchettoDao pDao = DBManager.getInstance().getPacchettoDao();
        Pacchetto pacchetto = new Pacchetto();

        AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();
        Agenzia agenzia = aDao.findByEmail(email);

        pacchetto.setDescrizione(descrizione);
        pacchetto.setId(id.longValue());
        pacchetto.setAgenzia(agenzia);
        pacchetto.setPrezzo(prezzo);
        pacchetto.setImmagine(immagineFile);
        pacchetto.setTitolo(titolo);


        pDao.saveOrUpdatePacchetto(pacchetto);

        return ResponseEntity.status(HttpStatus.CREATED).body("Pacchetto creato con successo!");
    }


    @PostMapping("addRecensione")
    public ResponseEntity<String> addRecensione( @RequestParam("utente") String email,
                                             @RequestParam("titolo") String titolo, @RequestParam("testo") String testo,
                                             @RequestParam("valutazione") Short valutazione){

        RecensioneDao rDao = DBManager.getInstance().getRecensioneDao();
        Recensione recensione = new Recensione();

        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        Utente utente = uDao.findByPrimaryKey(email);




        recensione.setId(0L);
        recensione.setUtente(utente);
        recensione.setTitolo(titolo);
        recensione.setTesto_rec(testo);
        recensione.setValutazione(valutazione);




        rDao.addRecensione(recensione);


        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

    }

    @GetMapping("getRecensioni")
    public List<Recensione> recensioni(){
        List<Recensione> recensioni = new ArrayList<>();

        recensioni = DBManager.getInstance().getRecensioneDao().findAll();

        return recensioni;
    }


    @PostMapping("addCliente")
    public ResponseEntity<String> addCliente(@RequestParam("id") Integer id, @RequestParam("utente") String utente,
                                             @RequestParam("autorizzato") boolean autorizzato){

            Utente u = DBManager.getInstance().getUtenteDao().findByPrimaryKey(utente);
            Cliente c = new Cliente();

            long longId = id;

            c.setId(longId);
            c.setUtente(u);
            c.setAutorizzato(autorizzato);
            ClienteDao cDao = DBManager.getInstance().getClienteDao();
            cDao.update(c);

            return ResponseEntity.status(HttpStatus.CREATED).body("Cliente creato con successo!");

    }

    @GetMapping("getPrenotazioniUtente")
    public List<Prenotazione> getPrenotazioni(@RequestParam("utente") String utente){
        Utente u = getUtente(utente);
        PrenotazioneDao pDAo = DBManager.getInstance().getPrenotazioneDao();
        return pDAo.findByUtenteLazy(u);

    }


    @GetMapping(value = "getRuolo", produces = "text/plain")
    public String getRuolo(@RequestParam("email") String email){

        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        if (uDao.findByPrimaryKey(email) != null){

            return uDao.findByPrimaryKey(email).getRuolo();
        }else{
            System.out.println("ELSE");
            return "";

    }
    }

    @GetMapping("" + "/getUtente")
    public Utente getUtente(@RequestParam("email") String email){


        Utente u = DBManager.getInstance().getUtenteDao().findByPrimaryKey(email);
        return u;

    }

    @GetMapping("getCliente")
    public Cliente getCliente(@RequestParam("email") String email){

        Cliente c = DBManager.getInstance().getClienteDao().findByEmail(email);
        return c;

    }



    /*@PostMapping("addUtente")
    public ResponseEntity<String> addUtente(@RequestBody Utente utente){
        System.out.println("nome: " + utente.getNome());
        UtenteDao uDao = DBManager.getInstance().getUtenteDao();
        uDao.saveOrUpdate(utente);

        System.out.println("dentro post");


        return ResponseEntity.status(HttpStatus.CREATED).body("Utente creato con successo!");

    }*/


    @GetMapping("camereDisp")
    public List <Integer> getCamereDisp(@RequestParam("date1") String date1, @RequestParam("date2") String date2){

        try {
            java.sql.Date sqlDate1 = java.sql.Date.valueOf(date1);
            java.sql.Date sqlDate2 = java.sql.Date.valueOf(date2);

            PrenotazioneDao pDAo = DBManager.getInstance().getPrenotazioneDao();
            List <Integer> camereLibera = pDAo.findyRoomsDisp(sqlDate1, sqlDate2);
            return camereLibera;

        } catch (Exception e) {
            throw new RuntimeException(e);

        }

    }

    @GetMapping("getPrezziStagioni")
    public List <Prezzo> getPrezzi() throws JsonProcessingException {
        PrezzoDao pDao = DBManager.getInstance().getPrezzoDao();

        List <Prezzo> prezzi = pDao.findAll();



        return prezzi;

    }

   @PostMapping("deleteAgenzia")
       public ResponseEntity<String> deleteAgenzia(@RequestParam("id") long id){

           AgenziaDao aDao = DBManager.getInstance().getAgenziaDao();

           Agenzia agenzia = aDao.findByPrimaryKey(id);

           aDao.delete(agenzia);



           return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

       }

    @PostMapping("deleteCliente")
    public ResponseEntity<String> deleteCliente(@RequestParam("id") long id){

        ClienteDao cDao = DBManager.getInstance().getClienteDao();

        Cliente cliente = cDao.findById(id);

        cDao.delete(cliente);



        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

    }

    @PostMapping("deletePacchetto")
    public ResponseEntity<String> deletePacchetto(@RequestParam("id") long id){
        PacchettoDao pDao = DBManager.getInstance().getPacchettoDao();

        Pacchetto pacchetto = pDao.findByPrimaryKey(id);

        pDao.delete(pacchetto);



        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

    }

    @PostMapping("deletePrenotazione")
    public ResponseEntity<String> deletePrenotazione(@RequestParam("id") long id){
        PrenotazioneDao pDao = DBManager.getInstance().getPrenotazioneDao();

        Prenotazione prenotazione = pDao.findByPrimaryKey(id);

        pDao.delete(prenotazione);



        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

    }

    @PostMapping("newAdmin")
    public ResponseEntity<String> newAdmin(@RequestParam("email") String email, @RequestParam("ruolo") String ruolo){
       UtenteDao uDao = DBManager.getInstance().getUtenteDao();

        Utente utente = uDao.findByPrimaryKey(email);

        utente.setRuolo(ruolo);

        uDao.saveOrUpdate(utente);



        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

    }

    @PostMapping("updatePrezzo")
    public ResponseEntity<String> newAdmin(@RequestParam("servizio") String servizio,@RequestParam("costo") BigDecimal costo,
                                           @RequestParam("sconto") BigDecimal sconto){
        PrezzoDao pDao = DBManager.getInstance().getPrezzoDao();

        Prezzo prezzo = new Prezzo();

        prezzo.setSconto(sconto);
        prezzo.setServizio(servizio);
        prezzo.setCosto(costo);

        pDao.saveOrUpdate(prezzo);


        return ResponseEntity.status(HttpStatus.CREATED).body("Prenotazione creata con successo!");

    }

    @GetMapping("getPacchettiProxy")

    public List<Pacchetto> getPacchettiProzy(@RequestParam("id") long id){
        List<Pacchetto> pacchetti = new ArrayList<>();
        AgenziaProxy agenziaProxy =new AgenziaProxy(DBManager.getInstance().getConnection(), id);
        pacchetti = agenziaProxy.getPacchetti();

        return pacchetti;
    }













}
