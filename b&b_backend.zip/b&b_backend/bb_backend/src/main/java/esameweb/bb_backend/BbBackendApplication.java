package esameweb.bb_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@SpringBootApplication
@ServletComponentScan
public class BbBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(BbBackendApplication.class, args);
    }

}
