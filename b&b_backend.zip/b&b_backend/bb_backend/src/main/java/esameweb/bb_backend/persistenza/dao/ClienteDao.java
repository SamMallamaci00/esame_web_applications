package esameweb.bb_backend.persistenza.dao;

import esameweb.bb_backend.persistenza.model.Cliente;

import java.util.List;

public interface ClienteDao {


    public List<Cliente>  findAll();

    public Cliente findByEmail(String email);

    public Cliente findById(Long id);

    void delete(Cliente cliente);

    void update(Cliente c);
}
