package esameweb.bb_backend.persistenza.model;

public class Camera {

    Long id;
}
