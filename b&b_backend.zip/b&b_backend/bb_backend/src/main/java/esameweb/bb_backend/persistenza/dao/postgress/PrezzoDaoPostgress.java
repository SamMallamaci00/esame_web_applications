package esameweb.bb_backend.persistenza.dao.postgress;

import com.fasterxml.jackson.annotation.JsonIgnoreType;
import esameweb.bb_backend.persistenza.dao.PrezzoDao;
import esameweb.bb_backend.persistenza.model.Prenotazione;
import esameweb.bb_backend.persistenza.model.Prezzo;
import org.springframework.aop.scope.ScopedProxyUtils;

import java.math.BigDecimal;
import java.sql.*;
import java.time.ZoneId;

import java.time.LocalDate;
import java.time.MonthDay;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class PrezzoDaoPostgress implements PrezzoDao {

    Connection conn;

    public PrezzoDaoPostgress(Connection conn) {
        this.conn = conn;
    }


    @Override
    public List<Prezzo> findAll() {

        List<Prezzo> prezzi = new ArrayList<>();

        String query = "select * from prezzo";

        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()){

                Prezzo prezzo = new Prezzo();
                prezzo.setServizio(rs.getString("servizio"));
                prezzo.setCosto(rs.getBigDecimal("costo"));
                prezzo.setSconto(rs.getBigDecimal("sconto"));

                prezzi.add(prezzo);

                System.out.println("Servizio: " + prezzo.getServizio());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return prezzi;


    }

    @Override
    public Prezzo findByPrimaryKey(String servizio) {

        Prezzo prezzo = new Prezzo();
        String query = "select * from prezzo where servizio = ?;";

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, servizio);
            ResultSet rs = st.executeQuery();

            if (rs.next()){
                prezzo.setCosto(rs.getBigDecimal("costo"));
                prezzo.setServizio(servizio);
                prezzo.setSconto(rs.getBigDecimal("sconto"));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prezzo;
    }

    @Override
    public void saveOrUpdate(Prezzo prezzo) {

        if(prezzo.getServizio() == null){

            String insertStr = "INSERT INTO prezzo VALUES (?, ?)";

            try {
                PreparedStatement st = conn.prepareStatement(insertStr);
                st.setString(1, prezzo.getServizio());
                st.setBigDecimal(2, prezzo.getCosto());

                st.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {

            String updateStr = "UPDATE prezzo set costo = ?, sconto = ? where servizio = ?;";

            try {
                PreparedStatement st = conn.prepareStatement(updateStr);
                st.setBigDecimal(1, prezzo.getCosto());
                st.setBigDecimal(2, prezzo.getSconto());

                st.setString(3, prezzo.getServizio());

                st.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

    }

    @Override
    public void delete(Prezzo prezzo) {
        String query = " DELETE FROM prezzo where servizio = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, prezzo.getServizio());
            st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }




    @Override
    public ArrayList<BigDecimal> findPrezzoByDates(Date dateInizio, Date dateFine, String tipoCamera) {

        System.out.println("Chiamata findByPrezzo");
        BigDecimal costoTotaleSenzaSconto = BigDecimal.ZERO;
        BigDecimal costoTotaleConSconto = BigDecimal.ZERO;


        ArrayList<Integer> index = new ArrayList<>();

        // Estrazione di mese e giorno per entrambe le date di inizio e fine
        Integer meseInizio = dateInizio.toLocalDate().getMonthValue();
        Integer giornoInizio = dateInizio.toLocalDate().getDayOfMonth();
        Integer meseFine = dateFine.toLocalDate().getMonthValue();
        Integer giornoFine = dateFine.toLocalDate().getDayOfMonth();


        Date inizioPren = new Date(2000 - 1900, meseInizio - 1, giornoInizio);
        Date finePren = new Date(2000 - 1900, meseFine - 1, giornoFine);

        LocalDate localDateFinePren = LocalDate.of(2000, meseFine, giornoFine);
        LocalDate localDateInizioPren = LocalDate.of(2000, meseInizio, giornoInizio);

        if (meseInizio == 12 && meseFine == 1) {

            localDateFinePren = LocalDate.of(2001, meseFine, giornoFine);
        }


        System.out.println("Mese inizio: " + meseInizio);



        System.out.println("Prima di eseguira prima query");
        String query = "SELECT s.id " +
                "FROM prezzo p " +
                "JOIN stagione s ON p.stagione = s.id " +
                "WHERE p.servizio LIKE ? " +
                "AND ( " +
                "    ( " +
                "        s.data_inizio <= CAST(? AS DATE) " +
                "        AND s.data_fine >= CAST(? AS DATE) " +
                "    ) " +
                "    OR " +
                "    ( " +
                "        s.data_inizio <= CAST(? AS DATE) " +
                "        AND s.data_fine >= CAST(? AS DATE) " +
                "    ) " +
                "    OR " +
                "    ( " +
                "        EXTRACT(MONTH FROM s.data_inizio) = EXTRACT(MONTH FROM CAST(? AS DATE)) + 11 " +
                "        AND s.data_fine >= CAST(? AS DATE) " +
                "    ) " +
                ") ";


        try (PreparedStatement st = conn.prepareStatement(query)) {
            // Impostazione dei parametri
            st.setString(1, "%" + tipoCamera + "%");
            st.setDate(2, inizioPren);
            st.setDate(3, inizioPren);
            st.setDate(4, finePren);
            st.setDate(5, finePren);
            st.setDate(6, finePren);
            st.setDate(7, finePren);
            /*st.setDate(8, nuovaFinePren);
            st.setDate(9, nuovaInizioPren);*/


            ResultSet rs = st.executeQuery();


            while (rs.next()) {
                System.out.println("Dentro rsnext prima query");
                System.out.println("id trovato: " + rs.getInt("id"));

                index.add(rs.getInt("id"));


            }
            System.out.println("Array index: " + index);


        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

        Integer x = index.get(index.size() - 1);

        while (x != index.get(0) + 1) {

            String query2 = "SELECT s.id, p.costo, s.data_inizio, s.data_fine, p.sconto " +
                    "FROM prezzo p " +
                    "JOIN stagione s ON p.stagione = s.id " +
                    "WHERE s.id = ? AND p.servizio LIKE ? ";


            try (PreparedStatement st2 = conn.prepareStatement(query2)) {

                st2.setInt(1, x);
                st2.setString(2, "%" + tipoCamera + "%"); // Data di inizio


                ResultSet rs2 = st2.executeQuery();


                while (rs2.next()) {

                    BigDecimal sconto = rs2.getBigDecimal("sconto");

                    System.out.println("Sconto: " + sconto);

                    Integer index2 = rs2.getInt("id");

                    System.out.println("ID dopo seconda query:  " + index2);

                    float costo = rs2.getFloat("costo");
                    Date dataInizioStag = rs2.getDate("data_inizio");
                    Date dataFineStag = rs2.getDate("data_fine");

                    System.out.println("Costo per notte: " + costo);

                    LocalDate inizioStagione = dataInizioStag.toLocalDate();
                    LocalDate fineStagione = dataFineStag.toLocalDate();

                    if (inizioStagione.getMonthValue() == 12 && fineStagione.getMonthValue() == 1) {
                        fineStagione = LocalDate.of(2001, fineStagione.getMonthValue(), fineStagione.getDayOfMonth());

                    }

                    if (localDateInizioPren.getMonthValue() == 12 && localDateFinePren.getMonthValue() == 1) {
                        localDateFinePren = LocalDate.of(2001, localDateFinePren.getMonthValue(), localDateFinePren.getDayOfMonth());
                        if(inizioStagione.getMonthValue() == 1 ){
                            fineStagione = LocalDate.of(2001, fineStagione.getMonthValue(), fineStagione.getDayOfMonth());
                            inizioStagione = LocalDate.of(2001, inizioStagione.getMonthValue(), inizioStagione.getDayOfMonth());

                        }
                    }



                    System.out.println("inizio stagione localdaet: " + inizioStagione);
                    System.out.println("fine stagione localdaet: " + fineStagione);

                    System.out.println("inizio prenotazione: " + localDateInizioPren);
                    System.out.println("fine prenotazione: " + localDateFinePren);


                    System.out.println("Prezzo stagione:  " + rs2.getFloat("costo"));
                    System.out.println("Data inizio: " + rs2.getDate("data_inizio"));
                    System.out.println("Data fine: " + rs2.getDate("data_fine"));


                    long giorniPrenotazioneStagione = 0;
                    if ((localDateInizioPren.isAfter(inizioStagione) || localDateInizioPren.isEqual(inizioStagione)) &&
                            (localDateFinePren.isBefore(fineStagione) || localDateFinePren.isEqual(fineStagione))) {
                        System.out.println("Dentro primo if");
                        giorniPrenotazioneStagione = ChronoUnit.DAYS.between(localDateInizioPren, localDateFinePren);

                    } else if (localDateInizioPren.isBefore(inizioStagione) || localDateInizioPren.isEqual(inizioStagione) &&
                            localDateFinePren.isBefore(fineStagione) || localDateFinePren.isEqual(fineStagione)
                    ) {
                        System.out.println("Dentro secondo if");
                        giorniPrenotazioneStagione = ChronoUnit.DAYS.between(inizioStagione, localDateFinePren);

                    }

                    else if ((localDateInizioPren.isAfter(inizioStagione) || localDateInizioPren.isEqual(inizioStagione))
                            && (localDateFinePren.isAfter(fineStagione)) || (localDateFinePren.isEqual(fineStagione))) {

                        System.out.println("Dentro terzo if");
                        giorniPrenotazioneStagione = ChronoUnit.DAYS.between(localDateInizioPren, fineStagione);

                    }


                    if (x != index.get(0) && giorniPrenotazioneStagione != 1) {
                        giorniPrenotazioneStagione += 1;

                    }

                    System.out.println("Id: " + x);
                    if (x == 6) {
                        x = 1;

                    } else {
                        x++;
                    }






                    BigDecimal costoNellaStagione = BigDecimal.valueOf(giorniPrenotazioneStagione * costo);


                    costoTotaleSenzaSconto =costoTotaleSenzaSconto.add(BigDecimal.valueOf(costo * giorniPrenotazioneStagione));

                    if(sconto != null && sconto != BigDecimal.valueOf(0)) {
                        BigDecimal prezzoScontato = costoNellaStagione.subtract((costoNellaStagione.multiply(sconto)).divide(BigDecimal.valueOf(100)));
                        costoTotaleConSconto = costoTotaleConSconto.add(prezzoScontato);
                    }

                }
            } catch (SQLException e) {
                System.err.println("Errore SQL: " + e.getMessage());
            }

        }
        ArrayList<BigDecimal> prezzi = new ArrayList<>();
        prezzi.add(costoTotaleSenzaSconto);
        prezzi.add(costoTotaleConSconto);
        return prezzi;

    }
}
