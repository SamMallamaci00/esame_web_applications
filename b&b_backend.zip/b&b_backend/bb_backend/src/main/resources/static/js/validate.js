utentiDaAggiungere = new Array()
clientiDaAggiungere = new Array ()

class Cliente{
    constructor(id, utente, autorizzato) {
        this.id = id;
        this.utente = utente;
        this.autorizzato = autorizzato;
    }
}


class Utente {
    constructor(nome, cognome, email, password, ruolo) {
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.ruolo = ruolo;
        this.password = password;
    }

}

function verificaUtenti(){
    var nomeUtenteTxt = document.getElementById("nome_ut").value.trim();
    var cognomeUtenteTxt = document.getElementById("cognome_ut").value.trim();
    var emailUtenteTxt = document.getElementById("email_ut").value.trim();
    var passUtenteTxt = document.getElementById("pass_ut").value.trim();
    var ruoloUtenteTxt = document.getElementById("ruolo_ut").value.trim();


    var ok = validateUtente(nomeUtenteTxt, cognomeUtenteTxt, emailUtenteTxt, passUtenteTxt, ruoloUtenteTxt);

    if(!ok){
        alert("Alcuni campi sono vuoti!");
    }else{
        alert("Campi validati");
    }
}

function validateUtente(nome, cognome, email, password, ruolo){
    var validation = true;
    if (nome == ""){
        validation = false;
    }
    if (cognome == ""){
        validation = false;
    }
     if (email == ""){
         validation = false;
     }
    if (password == ""){
        validation = false;
    }else{
        if (password.length < 8){
            alert("La password deve essere almeno 8 caratteri");
            validation = false;
            return;

        }
    }
    if (ruolo == ""){
        validation = false;
        return;

    }
    return validation;

}

function aggiungiUtente(){
    var nomeUtenteTxt = document.getElementById("nome_ut");
    var cognomeUtenteTxt = document.getElementById("cognome_ut");
    var emailUtenteTxt = document.getElementById("email_ut");
    var passUtenteTxt = document.getElementById("pass_ut");
    var ruoloUtenteTxt = document.getElementById("ruolo_ut");

    var nomeUt = nomeUtenteTxt.value.trim();
    var cognomeUt = cognomeUtenteTxt.value.trim();
    var emailUt = emailUtenteTxt.value.trim();
    var passUt = passUtenteTxt.value.trim();
    var ruoloUt = ruoloUtenteTxt.value.trim().toLowerCase();


    if (validateUtente(nomeUt, cognomeUt, emailUt, passUt, ruoloUt)) {
        nuovoUtente = new Utente(nomeUt, cognomeUt, emailUt, passUt, ruoloUt)
        utentiDaAggiungere.push(nuovoUtente);
        console.log("dentro aggiungi")
    }else{
        alert("Mancano dei campi");
        return;
    }


}


function salvaUtente(){

    var utentiJson = JSON.stringify(utentiDaAggiungere); // Converti l'oggetto in JSON
    console.log(utentiDaAggiungere);
    $.ajax({
        url: "addUtente",
        type: "POST",
        data: utentiJson,
        contentType: "application/json",
        success: function(risposta) {
            if (risposta == "OK") {
                alert("Utente creato con successo");
                let tutteLeRighe = document.querySelectorAll("tr");
                tutteLeRighe.forEach(function (riga) {
                        riga.style.removeProperty("font-weight");
                    }
                );
            }
        },
        error: function(xhr, status, error) {
            alert("Errore durante l'invio dei dati: " + error);
        }
    });
    /*var utente = utentiDaAggiungere[0];

    if(utente.ruolo === "Cliente"){
        var c = new Cliente(null, utente, false);
        clientiDaAggiungere.push(c);
        var clientiJson = JSON.stringify(clientiDaAggiungere); // Converti l'oggetto in JSON
        console.log(utentiDaAggiungere);
        $.ajax({
            url: "aggiungiCLiente",
            type: "POST",
            data: clientiJson,
            contentType: "application/json",
            success: function(risposta) {
                alert(risposta);
                if (risposta == "OK") {
                    //alert("SI");
                    let tutteLeRighe = document.querySelectorAll("tr");
                    tutteLeRighe.forEach(function (riga) {
                            riga.style.removeProperty("font-weight");
                        }
                    );
                }
            },
            error: function(xhr, status, error) {
                alert("Errore durante l'invio dei dati: " + error);
            }

    });
    };*/

}

function salvaCliente(){
    var utente = utentiDaAggiungere[0];

    if(utente.ruolo === "Cliente"){
        var c = new Cliente(null, utente, false);
        clientiDaAggiungere.push(c);
        var clientiJson = JSON.stringify(clientiDaAggiungere); // Converti l'oggetto in JSON
        console.log(utentiDaAggiungere);
        $.ajax({
            url: "aggiungiCLiente",
            type: "POST",
            data: clientiJson,
            contentType: "application/json",
            success: function(risposta) {
                alert(risposta);
                if (risposta == "OK") {
                    alert("Cliente creato con successo");
                    let tutteLeRighe = document.querySelectorAll("tr");
                    tutteLeRighe.forEach(function (riga) {
                            riga.style.removeProperty("font-weight");
                        }
                    );
                }
            },
            error: function(xhr, status, error) {
                alert("Errore durante l'invio dei dati: " + error);
            }

        });
    };

}





window.addEventListener("load", function() {

    var butVerifica = document.querySelector("#btn_verifica");
    butVerifica.addEventListener("click", function () {
        verificaUtenti();
    });

    var butSalva = document.querySelector("#btn_salva");
    butSalva.addEventListener("click", function () {
        aggiungiUtente();
        salvaUtente();
        salvaCliente()
    });
});